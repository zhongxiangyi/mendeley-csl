from __future__ import annotations

from pathlib import Path

import torch

from yolo_scm.model.losses import YoloScmLoss
from yolo_scm.model.network import YoloScm
from yolo_scm.model.parser import build_model


def _loss() -> YoloScmLoss:
    return YoloScmLoss({"box": 7.5, "cls": 0.5, "dfl": 1.5, "mask": 1.0, "dice": 1.0, "boundary": 0.5})


def _model() -> YoloScm:
    return build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))


def _target(classes: list[int]) -> list[dict[str, torch.Tensor]]:
    masks = torch.zeros((len(classes), 640, 640))
    boxes: list[list[float]] = []
    for index, class_id in enumerate(classes):
        x = 80 + index * 220
        masks[index, 100:180, x : x + 100] = 1.0
        boxes.append([float(x), 100.0, float(x + 100), 180.0])
    return [{"boxes": torch.tensor(boxes), "labels": torch.tensor(classes), "masks": masks}]


def test_single_target_assignment_has_foreground() -> None:
    output = _model().train()(torch.zeros(1, 3, 640, 640))
    assignment = _loss().assign(output, _target([0]))
    assert assignment.foreground_mask.any()


def test_multiple_targets_map_to_distinct_instances() -> None:
    output = _model().train()(torch.zeros(1, 3, 640, 640))
    assignment = _loss().assign(output, _target([0, 1]))
    indices = assignment.target_indices[0, assignment.foreground_mask[0]]
    assert set(indices.tolist()) == {0, 1}


def test_empty_targets_do_not_have_foreground() -> None:
    output = _model().train()(torch.zeros(1, 3, 640, 640))
    result = _loss()(output, [{"boxes": torch.zeros((0, 4)), "labels": torch.zeros((0,), dtype=torch.long), "masks": torch.zeros((0, 640, 640))}])
    assert not result.assignment.foreground_mask.any()
    assert torch.isfinite(result.total)


def test_training_step_has_finite_gradients() -> None:
    model = _model().train()
    result = _loss()(model(torch.randn(1, 3, 640, 640)), _target([0, 1]))
    assert result.total > 0
    result.total.backward()
    assert model.p3.cv1.conv.weight.grad is not None
    assert torch.isfinite(model.p3.cv1.conv.weight.grad).all()
