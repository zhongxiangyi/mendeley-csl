from __future__ import annotations

from pathlib import Path

import torch

from yolo_scm.cli.profile_model import profile_model
from yolo_scm.model.parser import build_model


def test_yolo_scm_forward_640() -> None:
    model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml")).eval()
    with torch.inference_mode():
        output = model(torch.zeros(1, 3, 640, 640))
    assert output.boxes.shape[0] == 1
    assert output.class_logits.shape[-1] == 2
    assert output.prototypes.shape[1] == 32


def test_model_target_complexity() -> None:
    model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))
    parameters, gflops = profile_model(model, model.input_size)
    assert abs(parameters / 1_000_000.0 - 9.1) / 9.1 <= 0.05
    assert abs(gflops - 26.8) / 26.8 <= 0.05
