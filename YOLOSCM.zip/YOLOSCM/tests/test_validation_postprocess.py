from __future__ import annotations

import numpy as np
import torch

from yolo_scm.engine.predictor import classwise_nms_indices, select_classwise_detections


def test_classwise_nms_preserves_synchronized_detection_indices() -> None:
    boxes = np.asarray([[10.0, 10.0, 30.0, 30.0], [11.0, 11.0, 31.0, 31.0], [10.0, 10.0, 30.0, 30.0]], dtype=np.float32)
    scores = np.asarray([0.99, 0.98, 0.97], dtype=np.float32)
    classes = np.asarray([0, 0, 1], dtype=np.int64)
    selected = classwise_nms_indices(boxes, scores, classes, 0.7, 300)
    assert selected.tolist() == [0, 2]
    logits = torch.tensor([[8.0, -8.0], [7.0, -8.0], [-8.0, 6.0]])
    selection = select_classwise_detections(torch.from_numpy(boxes), logits, 0.001, 0.7, 300)
    coefficients = torch.arange(12, dtype=torch.float32).reshape(3, 4)
    assert selection.indices.tolist() == [0, 2]
    assert selection.class_ids.tolist() == [0, 1]
    assert torch.equal(coefficients[selection.indices], torch.stack((coefficients[0], coefficients[2])))
