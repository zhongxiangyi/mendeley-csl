from __future__ import annotations

from pathlib import Path

from yolo_scm.quantification.export import export_measurements


def test_export_preserves_instance_order(tmp_path: Path) -> None:
    records = [{"image_id": "b", "instance_id": 1, "class_id": 0, "class_name": "crack", "confidence": 1.0, "bbox_xyxy": [0, 0, 1, 1], "mask_pixel_count": 1, "pixel_scale_x_mm": None, "pixel_scale_y_mm": None, "crack_length_mm": None, "maximum_crack_width_mm": None, "average_crack_width_mm": None, "median_crack_width_mm": None, "spalling_area_mm2": None, "spalling_area_cm2": None, "perimeter_mm": None, "reliable": False, "reliability_status": "pixel_only", "rejection_reasons": [], "calibration_residual_percent": None, "surface_angle_deg": 0.0}, {"image_id": "a", "instance_id": 0, "class_id": 1, "class_name": "spalling", "confidence": 1.0, "bbox_xyxy": [0, 0, 1, 1], "mask_pixel_count": 1, "pixel_scale_x_mm": None, "pixel_scale_y_mm": None, "crack_length_mm": None, "maximum_crack_width_mm": None, "average_crack_width_mm": None, "median_crack_width_mm": None, "spalling_area_mm2": None, "spalling_area_cm2": None, "perimeter_mm": None, "reliable": False, "reliability_status": "pixel_only", "rejection_reasons": [], "calibration_residual_percent": None, "surface_angle_deg": 0.0}]
    csv_path, json_path, _ = export_measurements(records, tmp_path)
    assert csv_path.exists() and json_path.exists()
