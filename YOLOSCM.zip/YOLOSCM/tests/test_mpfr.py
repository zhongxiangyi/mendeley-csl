from __future__ import annotations

import torch

from yolo_scm.model.mpfr import MPFR


def test_mpfr_divisible_shape() -> None:
    module = MPFR(64).eval()
    with torch.inference_mode():
        output = module(torch.randn(1, 64, 12, 16))
    assert output.shape == (1, 64, 12, 16)


def test_mpfr_padding_shape() -> None:
    module = MPFR(64).eval()
    with torch.inference_mode():
        output = module(torch.randn(1, 64, 13, 15))
    assert output.shape == (1, 64, 13, 15)
    assert module.last_weights is not None
    assert torch.allclose(module.last_weights.sum(dim=1), torch.ones(1), atol=1e-6)


def test_mpfr_unfold_fold_identity() -> None:
    module = MPFR(16)
    value = torch.randn(1, 16, 32, 32)
    tokens, output_size = module.unfold_tokens(value)
    reconstructed = module.fold_tokens(tokens, output_size)
    assert torch.allclose(value, reconstructed, atol=1e-6)


def test_mpfr_preserves_thin_line_and_backpropagates() -> None:
    module = MPFR(16)
    value = torch.zeros(1, 16, 31, 29, requires_grad=True)
    value.data[:, :, 15, :] = 1.0
    output = module(value)
    assert output.abs().sum() > 0
    output.mean().backward()
    assert value.grad is not None
