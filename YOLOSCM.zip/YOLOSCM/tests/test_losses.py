from __future__ import annotations

from pathlib import Path

import torch

from yolo_scm.model.losses import YoloScmLoss, boundary_band
from yolo_scm.model.parser import build_model


def test_loss_is_finite_and_backpropagates() -> None:
    model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))
    images = torch.randn(1, 3, 640, 640)
    output = model(images)
    mask = torch.zeros(1, 640, 640)
    mask[:, 100:160, 100:160] = 1
    target = [{"boxes": torch.tensor([[100.0, 100.0, 160.0, 160.0]]), "labels": torch.tensor([0]), "masks": mask}]
    loss = YoloScmLoss({"box": 7.5, "cls": 0.5, "dfl": 1.5, "mask": 1.0, "dice": 1.0, "boundary": 0.5})(output, target)
    assert torch.isfinite(loss.total)
    loss.total.backward()
    assert model.stem.conv.weight.grad is not None


def test_boundary_band_empty_mask() -> None:
    band = boundary_band(torch.zeros(1, 1, 16, 16))
    assert band.sum() == 0


def test_three_pixel_boundary_band_uses_three_by_three_kernel() -> None:
    mask = torch.zeros(1, 9, 9)
    mask[:, 4, 4] = 1.0
    band = boundary_band(mask, band_width_pixels=3)
    assert band.sum() == 9
    assert torch.equal(band[0, 3:6, 3:6], torch.ones(3, 3))
