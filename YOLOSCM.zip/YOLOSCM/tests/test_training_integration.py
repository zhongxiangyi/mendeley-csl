from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import yaml

from yolo_scm.engine.trainer import train_seed
from yolo_scm.model.parser import build_model


def _write_dataset(root: Path) -> Path:
    for split in ("train", "val"):
        image_directory = root / "data" / "images" / split
        label_directory = root / "data" / "labels" / split
        image_directory.mkdir(parents=True)
        label_directory.mkdir(parents=True)
        image = np.full((640, 640, 3), 150, dtype=np.uint8)
        cv2.rectangle(image, (120, 120), (220, 220), (50, 50, 50), -1)
        if not cv2.imwrite(str(image_directory / "sample.png"), image):
            raise IOError("failed to write integration image")
        (label_directory / "sample.txt").write_text("0 0.2 0.2 0.35 0.2 0.35 0.35 0.2 0.35\n", encoding="utf-8")
    config = {"path": str(root / "data"), "train": "images/train", "val": "images/val", "test": "images/val", "measurement_val": "images/val", "names": {0: "crack", 1: "spalling"}, "group_metadata": "groups.csv"}
    path = root / "data.yaml"
    path.write_text(yaml.safe_dump(config), encoding="utf-8")
    return path


def test_minimal_training_and_validation_step(tmp_path: Path) -> None:
    data = _write_dataset(tmp_path)
    paper = yaml.safe_load(Path("configs/paper.yaml").read_text(encoding="utf-8"))
    paper["training"]["batch_size"] = 1
    paper["training"]["max_epochs"] = 1
    paper["training"]["warmup_epochs"] = 0
    paper["training"]["early_stopping_patience"] = 1
    paper_path = tmp_path / "paper.yaml"
    paper_path.write_text(yaml.safe_dump(paper), encoding="utf-8")
    defaults = yaml.safe_load(Path("configs/implementation_defaults.yaml").read_text(encoding="utf-8"))
    defaults["implementation_defaults"]["workers"] = 0
    defaults_path = tmp_path / "defaults.yaml"
    defaults_path.write_text(yaml.safe_dump(defaults), encoding="utf-8")
    result = train_seed(build_model(paper_path, defaults_path), data, paper_path, defaults_path, tmp_path / "runs", 2022, max_epochs_override=1)
    run = tmp_path / "runs" / "seed_2022"
    assert result["best_validation_loss"] >= 0.0
    assert (run / "best.pt").exists()
    assert (run / "last.pt").exists()
    assert (run / "metrics.csv").exists()
    assert (run / "metrics.json").exists()
