from __future__ import annotations

from pathlib import Path

import onnx

from yolo_scm.cli.export_onnx import main


def test_onnx_export_and_runtime(tmp_path: Path) -> None:
    output = tmp_path / "model.onnx"
    assert main(["--config", "configs/paper.yaml", "--output", str(output), "--smoke-test"]) == 0
    onnx.checker.check_model(onnx.load(str(output)))
