from __future__ import annotations

import numpy as np
from pathlib import Path
import csv
import json

from yolo_scm.calibration.scale import ruler_scale
from yolo_scm.calibration.validation import validate_measurement
from yolo_scm.engine.pipeline import _record, run_pipeline
from yolo_scm.engine.predictor import InstancePrediction
from yolo_scm.quantification.crack import quantify_crack
from yolo_scm.quantification.agreement import agreement_statistics
from yolo_scm.quantification.uncertainty import UncertaintyComponent, gum_uncertainty


def test_gum_and_bland_altman() -> None:
    uncertainty = gum_uncertainty([UncertaintyComponent("reference_instrument", 1.0, 0.02), UncertaintyComponent("scale_calibration", 2.0, 0.01)])
    assert abs(uncertainty["combined_standard_uncertainty"] - np.sqrt(0.0008)) < 1e-9
    agreement = agreement_statistics(np.asarray([1.1, 2.1, 3.1]), np.asarray([1.0, 2.0, 3.0]))
    assert abs(agreement["bland_altman_mean_difference"] - 0.1) < 1e-9


def test_single_image_pipeline_smoke(tmp_path: Path) -> None:
    output = tmp_path / "results"
    result = run_pipeline(None, None, output, smoke_test=True)
    assert len(result) == 2
    assert {record["class_name"] for record in result} == {"crack", "spalling"}
    crack = next(record for record in result if record["class_name"] == "crack")
    spalling = next(record for record in result if record["class_name"] == "spalling")
    assert crack["crack_length_mm"] is not None
    assert spalling["spalling_area_mm2"] is not None
    assert spalling["reliability_status"] == "provisional_calibration"
    assert (output / "measurements.csv").exists()
    assert (output / "measurements.json").exists()


def test_smoke_csv_and_json_instance_order_match(tmp_path: Path) -> None:
    output = tmp_path / "results"
    run_pipeline(None, None, output, smoke_test=True)
    with (output / "measurements.csv").open("r", encoding="utf-8", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    json_rows = json.loads((output / "measurements.json").read_text(encoding="utf-8"))
    assert [(row["image_id"], int(row["instance_id"])) for row in csv_rows] == [(row["image_id"], row["instance_id"]) for row in json_rows]


def test_fitted_only_default_outputs_pixel_measurements_only() -> None:
    mask = np.zeros((32, 32), dtype=np.uint8)
    mask[15:18, 5:26] = 1
    metadata = {"mode": "ruler", "surface_angle_deg": 0.0, "environment": "laboratory"}
    scale = ruler_scale([[0.0, 0.0], [100.0, 0.0]], 5.0)
    decision = validate_measurement(metadata, scale)
    crack = quantify_crack(mask, None)
    prediction = InstancePrediction(0, 1.0, [5.0, 15.0, 26.0, 18.0], mask.astype(np.float32))
    record = _record("fitted", 0, prediction, mask, scale, decision, metadata, crack, None)
    assert not record["reliable"]
    assert record["reliability_status"] == "provisional_calibration"
    assert record["crack_length_pixels"] is not None
    assert record["crack_length_mm"] is None
    assert record["pixel_scale_x_mm"] is None
