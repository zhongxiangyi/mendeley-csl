from __future__ import annotations

import numpy as np

from yolo_scm.calibration.scale import ImageScale
from yolo_scm.quantification.spalling import quantify_spalling


def test_rectangle_spalling_area() -> None:
    mask = np.zeros((20, 20), dtype=np.uint8)
    mask[2:12, 3:13] = 1
    result = quantify_spalling(mask, ImageScale(0.5, 0.5, 0.0, "planar_marker"))
    assert result["pixel_area"] == 100
    assert result["area_mm2"] == 25.0
    assert result["area_cm2"] == 0.25


def test_invalid_calibration_is_pixel_only() -> None:
    mask = np.ones((4, 4), dtype=np.uint8)
    result = quantify_spalling(mask, None)
    assert result["area_mm2"] is None
    assert result["pixel_area"] == 16
