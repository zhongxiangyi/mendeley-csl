from __future__ import annotations

import pytest
import torch

from yolo_scm.model.shuffle_attention import ShuffleAttention


def test_shuffle_attention_forward_and_backward() -> None:
    module = ShuffleAttention(64, groups=8)
    value = torch.randn(2, 64, 12, 10, requires_grad=True)
    output = module(value)
    assert output.shape == value.shape
    output.mean().backward()
    assert value.grad is not None
    assert torch.isfinite(value.grad).all()


def test_shuffle_attention_requires_eight_valid_groups() -> None:
    with pytest.raises(ValueError):
        ShuffleAttention(60, groups=8)
