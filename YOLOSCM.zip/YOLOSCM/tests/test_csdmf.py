from __future__ import annotations

import torch

from yolo_scm.model.csdmf import CSDMF


def test_csdmf_weights_and_shape() -> None:
    module = CSDMF(512, 256, 128, 256, 256, (1, 7), (7, 1), (2, 3)).eval()
    with torch.inference_mode():
        output = module(torch.randn(2, 512, 8, 8), torch.randn(2, 256, 16, 16), torch.randn(2, 128, 32, 32))
    assert output.shape == (2, 256, 8, 8)
    assert module.input_channels == 512
    assert module.output_channels == 256
    assert module.last_weights is not None
    assert torch.all(module.last_weights >= 0)
    assert torch.allclose(module.last_weights.sum(dim=1), torch.ones(2), atol=1e-6)
