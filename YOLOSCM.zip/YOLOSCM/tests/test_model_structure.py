from __future__ import annotations

from pathlib import Path

import torch
from ultralytics.nn.modules import C2f

from yolo_scm.model.c3k2sa import C3K2SA
from yolo_scm.model.csdmf import CSDMF
from yolo_scm.model.mpfr import MPFR
from yolo_scm.model.parser import build_model, load_yolov10s_config


def test_official_yolov10s_configuration_is_available() -> None:
    config = load_yolov10s_config()
    assert "backbone" in config and "head" in config


def test_stage_and_neck_module_positions() -> None:
    model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))
    assert isinstance(model.stage2, C2f)
    assert not isinstance(model.stage2, C3K2SA)
    assert all(isinstance(item, C3K2SA) for item in (model.p3, model.p4, model.p5))
    assert isinstance(model.csdmf, CSDMF)
    assert model.csdmf.input_channels == model.config.channels["p5"] == model.config.csdmf["input_channels"]
    assert model.csdmf.output_channels == model.config.csdmf["output_channels"]
    assert len(model.p3.blocks) == model.config.repeats["p3"]
    assert len(model.p4.blocks) == model.config.repeats["p4"]
    assert len(model.p5.blocks) == model.config.repeats["p5"]
    assert all(isinstance(item, MPFR) for item in (model.mpfr_top, model.mpfr_mid, model.mpfr_bottom, model.mpfr_out))


def test_compatible_weight_loading_reports_mismatches(tmp_path: Path) -> None:
    source = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))
    checkpoint = tmp_path / "source.pt"
    torch.save({"model": source.state_dict()}, checkpoint)
    report = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml")).load_pretrained(checkpoint)
    assert report["loaded_parameter_count"] > 0
    assert isinstance(report["unmatched_layers"], list)
