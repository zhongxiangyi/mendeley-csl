from __future__ import annotations

import numpy as np

from yolo_scm.calibration.scale import ImageScale
from yolo_scm.quantification.crack import quantify_crack
from yolo_scm.quantification.refinement import restore_probability_mask


def test_known_line_skeleton_length() -> None:
    mask = np.zeros((32, 32), dtype=np.uint8)
    mask[15:18, 5:26] = 1
    result = quantify_crack(mask, ImageScale(1.0, 1.0, 0.0, "ruler"))
    assert abs(result["crack_length_mm"] - 20.0) <= 2.0


def test_rectangle_width_and_minimum_width_filter() -> None:
    mask = np.zeros((32, 40), dtype=np.uint8)
    mask[10:20, 5:35] = 1
    result = quantify_crack(mask, ImageScale(1.0, 1.0, 0.0, "ruler"))
    assert result["all_width_statistics"]["maximum_width_mm"] is not None
    narrow = np.zeros((20, 20), dtype=np.uint8)
    narrow[8:10, 2:18] = 1
    narrow_result = quantify_crack(narrow, ImageScale(1.0, 1.0, 0.0, "ruler"))
    assert narrow_result["reliable_width_statistics"]["valid_width_point_count"] == 0


def test_original_resolution_restore_and_invalid_scale() -> None:
    probability = np.full((8, 8), 0.75, dtype=np.float32)
    restored = restore_probability_mask(probability, (31, 47))
    assert restored.shape == (31, 47)
    result = quantify_crack((restored > 0.5).astype(np.uint8), None)
    assert result["crack_length_mm"] is None
