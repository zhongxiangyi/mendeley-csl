from __future__ import annotations

import numpy as np

from yolo_scm.calibration.homography import marker_homography, warp_image_and_mask
from yolo_scm.calibration.scale import fit_ruler_scale, ruler_scale
from yolo_scm.calibration.validation import validate_measurement


def test_ruler_scale() -> None:
    scale = ruler_scale([[0.0, 0.0], [100.0, 0.0]], 25.0)
    assert scale.isotropic_mm_per_pixel == 0.25


def test_marker_homography_25_by_30() -> None:
    result = marker_homography([[10.0, 10.0], [110.0, 10.0], [110.0, 130.0], [10.0, 130.0]])
    image = np.zeros((140, 120, 3), dtype=np.uint8)
    mask = np.zeros((140, 120), dtype=np.uint8)
    mask[10:130, 10:110] = 1
    _, warped = warp_image_and_mask(image, mask, result)
    assert result.output_size[0] >= 250
    assert result.output_size[1] >= 300
    assert warped.shape == (result.output_size[1], result.output_size[0])
    assert abs(result.scale.x_mm_per_pixel - 0.1) < 1e-9
    assert abs(result.scale.y_mm_per_pixel - 0.1) < 1e-9
    assert result.homography_fitting_residual_percent >= 0.0
    assert result.calibration_validation_status == "fitted_only"


def test_multisegment_ruler_residual_is_computed() -> None:
    scale = fit_ruler_scale([{"points": [[0.0, 0.0], [100.0, 0.0]], "reference_length_mm": 5.0}, {"points": [[0.0, 0.0], [200.0, 0.0]], "reference_length_mm": 10.0}], [{"points": [[0.0, 0.0], [300.0, 0.0]], "reference_length_mm": 15.0}])
    assert scale.calibration_validation_status == "independently_validated"
    assert scale.residual_percent is not None
    assert scale.residual_percent < 1e-8


def test_single_segment_is_provisional() -> None:
    scale = ruler_scale([[0.0, 0.0], [100.0, 0.0]], 5.0)
    decision = validate_measurement({"surface_angle_deg": 0.0, "environment": "laboratory"}, scale)
    assert scale.residual_percent is None
    assert scale.calibration_validation_status == "fitted_only"
    assert decision.status == "provisional_calibration"
    assert not decision.reliable


def test_single_segment_provisional_measurement_can_be_explicitly_allowed() -> None:
    scale = ruler_scale([[0.0, 0.0], [100.0, 0.0]], 5.0)
    decision = validate_measurement({"surface_angle_deg": 0.0, "environment": "laboratory", "allow_provisional_calibration": True}, scale)
    assert decision.status == "provisional_calibration"
    assert decision.reliable


def test_marker_validation_points_enable_strict_residual() -> None:
    result = marker_homography([[10.0, 10.0], [110.0, 10.0], [110.0, 130.0], [10.0, 130.0]], validation_points=[{"image_point": [60.0, 70.0], "physical_point_mm": [12.5, 15.0]}])
    assert result.calibration_validation_status == "independently_validated"
    assert result.scale.residual_percent is not None


def test_full_homography_canvas_preserves_distant_damage() -> None:
    image = np.zeros((600, 900, 3), dtype=np.uint8)
    mask = np.zeros((600, 900), dtype=np.uint8)
    mask[450:570, 720:880] = 1
    result = marker_homography([[30.0, 30.0], [530.0, 30.0], [530.0, 630.0], [30.0, 630.0]], image.shape[:2], np.asarray([[720.0, 450.0], [880.0, 570.0]], dtype=np.float32), pixels_per_mm=20.0)
    _, warped = warp_image_and_mask(image, mask, result)
    assert warped.sum() > 0
