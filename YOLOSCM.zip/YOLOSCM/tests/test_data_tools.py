from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from yolo_scm.data.group_split import create_group_split
from yolo_scm.data.xanylabeling_converter import convert_xanylabeling_json


def test_group_split_has_no_group_leakage(tmp_path: Path) -> None:
    rows = [{"image": f"image_{group}_{index}.jpg", "group_id": f"group_{group}", "source": "s", "scene": "scene", "specimen_id": f"specimen_{group}"} for group in range(10) for index in range(2)]
    metadata = tmp_path / "groups.csv"
    output = tmp_path / "split.csv"
    pd.DataFrame(rows).to_csv(metadata, index=False)
    result = create_group_split(metadata, output)
    assert result.groupby("group_id")["split"].nunique().max() == 1


def test_xanylabeling_conversion_preserves_class_mapping(tmp_path: Path) -> None:
    source = tmp_path / "annotation.json"
    destination = tmp_path / "label.txt"
    source.write_text(json.dumps({"imageWidth": 100, "imageHeight": 50, "shapes": [{"label": "crack", "points": [[0, 0], [10, 0], [10, 10]]}, {"label": "spalling", "points": [[20, 20], [40, 20], [40, 40]]}]}), encoding="utf-8")
    assert convert_xanylabeling_json(source, destination) == 2
    lines = destination.read_text(encoding="utf-8").splitlines()
    assert lines[0].startswith("0 ") and lines[1].startswith("1 ")


def test_xanylabeling_rejects_invalid_polygon(tmp_path: Path) -> None:
    source = tmp_path / "invalid.json"
    source.write_text(json.dumps({"imageWidth": 100, "imageHeight": 50, "shapes": [{"label": "crack", "points": [[0, 0], [10, 0]]}]}), encoding="utf-8")
    with pytest.raises(ValueError):
        convert_xanylabeling_json(source, tmp_path / "label.txt")


def test_empty_xanylabeling_annotation_is_supported(tmp_path: Path) -> None:
    source = tmp_path / "empty.json"
    destination = tmp_path / "label.txt"
    source.write_text(json.dumps({"imageWidth": 100, "imageHeight": 50, "shapes": []}), encoding="utf-8")
    assert convert_xanylabeling_json(source, destination) == 0
    assert destination.read_text(encoding="utf-8") == ""
