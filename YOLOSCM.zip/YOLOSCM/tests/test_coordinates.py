from __future__ import annotations

import numpy as np

from yolo_scm.engine.predictor import letterbox_image, restore_letterbox_probability


def test_letterbox_restores_original_shape() -> None:
    image = np.zeros((720, 960, 3), dtype=np.uint8)
    _, transform = letterbox_image(image)
    probability = np.zeros((640, 640), dtype=np.float32)
    left, top, right, bottom = transform.padding
    probability[top : 640 - bottom, left : 640 - right] = 1.0
    restored = restore_letterbox_probability(probability, transform)
    assert restored.shape == image.shape[:2]
    assert restored.mean() > 0.99


def test_letterbox_rejects_wrong_model_mask_size() -> None:
    image = np.zeros((720, 960, 3), dtype=np.uint8)
    _, transform = letterbox_image(image)
    try:
        restore_letterbox_probability(np.zeros((320, 320), dtype=np.float32), transform)
    except ValueError:
        return
    raise AssertionError("wrong model mask size must raise ValueError")
