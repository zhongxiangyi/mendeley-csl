from __future__ import annotations

import numpy as np
import pytest

from yolo_scm.engine.evaluator import EvaluatedInstance, evaluate_instances


def _instance(image_id: str, class_id: int, confidence: float, mask: np.ndarray) -> EvaluatedInstance:
    ys, xs = np.nonzero(mask)
    return EvaluatedInstance(image_id, class_id, confidence, mask, np.asarray([xs.min(), ys.min(), xs.max() + 1, ys.max() + 1], dtype=np.float32))


def test_perfect_instance_metrics_are_one() -> None:
    crack = np.zeros((32, 32), dtype=bool)
    spalling = np.zeros((32, 32), dtype=bool)
    crack[2:8, 2:20] = True
    spalling[16:28, 12:25] = True
    metrics = evaluate_instances([_instance("a", 0, 0.9, crack), _instance("a", 1, 0.8, spalling)], [_instance("a", 0, 1.0, crack), _instance("a", 1, 1.0, spalling)])
    assert metrics["mask_mAP50"] > 0.99
    assert metrics["IoU_crack"] > 0.99
    assert metrics["IoU_spalling"] > 0.99


def test_wrong_class_is_not_matched() -> None:
    mask = np.zeros((24, 24), dtype=bool)
    mask[3:14, 3:14] = True
    metrics = evaluate_instances([_instance("a", 1, 0.9, mask)], [_instance("a", 0, 1.0, mask)])
    assert metrics["recall_crack"] == 0.0


def test_duplicate_prediction_counts_false_positive() -> None:
    mask = np.zeros((24, 24), dtype=bool)
    mask[3:14, 3:14] = True
    metrics = evaluate_instances([_instance("a", 0, 0.9, mask), _instance("a", 0, 0.8, mask)], [_instance("a", 0, 1.0, mask)])
    assert metrics["precision_crack"] == 1.0
    assert metrics["best_F1_confidence_crack"] == 0.9


def test_mismatched_mask_coordinates_fail() -> None:
    with pytest.raises(ValueError):
        evaluate_instances([_instance("a", 0, 0.9, np.ones((8, 8), dtype=bool))], [_instance("a", 0, 1.0, np.ones((9, 9), dtype=bool))])
