from __future__ import annotations

from yolo_scm.engine.trainer import update_best_state


def test_best_epoch_and_evaluation_remain_at_lowest_validation_loss() -> None:
    best_loss = float("inf")
    best_epoch = -1
    best_evaluation: dict[str, float] = {}
    for epoch, loss in enumerate((0.8, 0.4, 0.6)):
        best_loss, best_epoch, best_evaluation, _ = update_best_state(best_loss, best_epoch, best_evaluation, loss, epoch, {"mask_mAP50": float(epoch)})
    assert best_loss == 0.4
    assert best_epoch == 1
    assert best_evaluation == {"mask_mAP50": 1.0}
