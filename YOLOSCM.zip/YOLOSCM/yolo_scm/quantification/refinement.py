from __future__ import annotations

import cv2
import numpy as np


def restore_probability_mask(probability_mask: np.ndarray, original_size: tuple[int, int]) -> np.ndarray:
    if probability_mask.ndim != 2:
        raise ValueError("probability mask must be two dimensional")
    height, width = original_size
    if height <= 0 or width <= 0:
        raise ValueError("original size must be positive")
    return cv2.resize(probability_mask.astype(np.float32), (width, height), interpolation=cv2.INTER_LINEAR)


def remove_small_components(mask: np.ndarray, minimum_pixels: int = 12) -> np.ndarray:
    if minimum_pixels < 1:
        raise ValueError("minimum_pixels must be positive")
    count, labels, statistics, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    output = np.zeros_like(mask, dtype=np.uint8)
    for label in range(1, count):
        if int(statistics[label, cv2.CC_STAT_AREA]) >= minimum_pixels:
            output[labels == label] = 1
    return output


def refine_instance_mask(probability_mask: np.ndarray, image_rgb: np.ndarray, class_id: int, threshold: float = 0.5, hsv_tolerance_fraction: float = 0.1, closing_kernel_size: int = 5, minimum_pixels: int = 12) -> np.ndarray:
    if image_rgb.ndim != 3 or image_rgb.shape[2] != 3:
        raise ValueError("image_rgb must have shape HxWx3")
    if probability_mask.shape != image_rgb.shape[:2]:
        raise ValueError("probability mask and image dimensions differ")
    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be between zero and one")
    binary = (probability_mask >= threshold).astype(np.uint8)
    if int(binary.sum()) == 0:
        return binary
    if class_id == 0:
        hsv = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2HSV).astype(np.float32)
        samples = hsv[binary.astype(bool)]
        lower = np.maximum(0.0, samples.mean(axis=0) * (1.0 - hsv_tolerance_fraction))
        upper = np.minimum(np.asarray([179.0, 255.0, 255.0]), samples.mean(axis=0) * (1.0 + hsv_tolerance_fraction))
        color_match = np.all((hsv >= lower) & (hsv <= upper), axis=2)
        binary = (binary.astype(bool) & color_match).astype(np.uint8)
    kernel = np.ones((closing_kernel_size, closing_kernel_size), dtype=np.uint8)
    closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
    return remove_small_components(closed, minimum_pixels)


def display_mask(measurement_mask: np.ndarray, dilation_pixels: int = 2) -> np.ndarray:
    if dilation_pixels < 0:
        raise ValueError("dilation_pixels cannot be negative")
    if dilation_pixels == 0:
        return measurement_mask.astype(np.uint8).copy()
    kernel = np.ones((2 * dilation_pixels + 1, 2 * dilation_pixels + 1), dtype=np.uint8)
    return cv2.dilate(measurement_mask.astype(np.uint8), kernel)
