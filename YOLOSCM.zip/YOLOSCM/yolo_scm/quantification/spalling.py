from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from yolo_scm.calibration.scale import ImageScale


def quantify_spalling(mask: np.ndarray, scale: ImageScale | None) -> dict[str, Any]:
    if mask.ndim != 2:
        raise ValueError("spalling mask must be two dimensional")
    binary = mask.astype(np.uint8)
    pixel_area = int(binary.sum())
    count, _, _, centroids = cv2.connectedComponentsWithStats(binary, connectivity=8)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contour_points = [contour.reshape(-1, 2).astype(float).tolist() for contour in contours]
    if pixel_area == 0:
        return {"pixel_area": 0, "area_mm2": None, "area_cm2": None, "perimeter_mm": None, "connected_component_count": 0, "contour_points": [], "bounding_box": None, "centroid": None}
    ys, xs = np.nonzero(binary)
    bounding_box = [int(xs.min()), int(ys.min()), int(xs.max() + 1), int(ys.max() + 1)]
    centroid = [float(centroids[1:, 0].mean()), float(centroids[1:, 1].mean())]
    if scale is None:
        return {"pixel_area": pixel_area, "area_mm2": None, "area_cm2": None, "perimeter_mm": None, "connected_component_count": count - 1, "contour_points": contour_points, "bounding_box": bounding_box, "centroid": centroid}
    perimeter_pixels = float(sum(cv2.arcLength(contour, True) for contour in contours))
    perimeter_scale = (scale.x_mm_per_pixel + scale.y_mm_per_pixel) / 2.0
    area_mm2 = float(pixel_area * scale.x_mm_per_pixel * scale.y_mm_per_pixel)
    return {"pixel_area": pixel_area, "area_mm2": area_mm2, "area_cm2": area_mm2 / 100.0, "perimeter_mm": perimeter_pixels * perimeter_scale, "connected_component_count": count - 1, "contour_points": contour_points, "bounding_box": bounding_box, "centroid": centroid}
