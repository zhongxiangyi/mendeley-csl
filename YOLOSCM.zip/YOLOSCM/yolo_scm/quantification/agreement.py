from __future__ import annotations

from typing import Any
from pathlib import Path

import numpy as np
import pandas as pd


def load_reference_measurements(path: Path) -> pd.DataFrame:
    table = pd.read_csv(path)
    required = {"image_id", "instance_id", "class_name", "reference_max_width_mm", "reference_average_width_mm", "reference_length_mm", "reference_area_cm2", "operator_id", "repeat_id"}
    missing = required.difference(table.columns)
    if missing:
        raise ValueError(f"missing reference fields: {sorted(missing)}")
    return table


def agreement_statistics(predicted: np.ndarray, reference: np.ndarray) -> dict[str, float]:
    values = np.asarray(predicted, dtype=np.float64)
    targets = np.asarray(reference, dtype=np.float64)
    if values.ndim != 1 or targets.ndim != 1 or values.size != targets.size or values.size == 0:
        raise ValueError("predicted and reference must be non-empty one-dimensional arrays of equal length")
    difference = values - targets
    mean_difference = float(difference.mean())
    standard_deviation = float(difference.std(ddof=1)) if difference.size > 1 else 0.0
    confidence_interval = 1.96 * standard_deviation / np.sqrt(difference.size)
    nonzero = np.abs(targets) > 1e-12
    mrel = float(np.mean(np.abs(difference[nonzero] / targets[nonzero]))) if np.any(nonzero) else float("nan")
    repeatability_cv = float(standard_deviation / np.mean(np.abs(values)) * 100.0) if np.mean(np.abs(values)) > 1e-12 else float("nan")
    return {"bias": mean_difference, "mae": float(np.mean(np.abs(difference))), "rmse": float(np.sqrt(np.mean(difference**2))), "mre": mrel, "standard_deviation": standard_deviation, "confidence_interval_95": float(confidence_interval), "bland_altman_mean_difference": mean_difference, "bland_altman_lower_limit": float(mean_difference - 1.96 * standard_deviation), "bland_altman_upper_limit": float(mean_difference + 1.96 * standard_deviation), "repeatability_coefficient_of_variation": repeatability_cv}
