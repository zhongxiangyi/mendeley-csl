from yolo_scm.quantification.crack import quantify_crack
from yolo_scm.quantification.spalling import quantify_spalling

__all__ = ["quantify_crack", "quantify_spalling"]
