from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import math
import yaml


@dataclass
class UncertaintyComponent:
    name: str
    partial_f_partial_xi: float
    standard_uncertainty: float


def gum_uncertainty(components: list[UncertaintyComponent], coverage_factor: float = 2.0) -> dict[str, Any]:
    if coverage_factor <= 0:
        raise ValueError("coverage_factor must be positive")
    contributions = {component.name: (component.partial_f_partial_xi * component.standard_uncertainty) ** 2 for component in components}
    combined = math.sqrt(sum(contributions.values()))
    return {"combined_standard_uncertainty": combined, "expanded_uncertainty": coverage_factor * combined, "coverage_factor": coverage_factor, "component_contributions": contributions}


def uncertainty_from_mapping(values: Mapping[str, Mapping[str, float]], coverage_factor: float = 2.0) -> dict[str, Any]:
    required = {"reference_instrument", "scale_calibration", "lens_correction", "perspective_correction", "segmentation_boundary", "skeleton_fluctuation", "operator_tracing", "repeatability"}
    missing = required.difference(values)
    if missing:
        raise ValueError(f"missing uncertainty components: {sorted(missing)}")
    components = [UncertaintyComponent(name, float(value["partial_f_partial_xi"]), float(value["standard_uncertainty"])) for name, value in values.items()]
    return gum_uncertainty(components, coverage_factor)


def uncertainty_from_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict) or "components" not in value:
        raise ValueError("uncertainty YAML requires components")
    components = value["components"]
    if not isinstance(components, dict):
        raise ValueError("components must be a mapping")
    return uncertainty_from_mapping(components, float(value.get("coverage_factor", 2.0)))
