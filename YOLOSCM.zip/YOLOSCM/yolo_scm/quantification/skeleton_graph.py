from __future__ import annotations

import heapq
from dataclasses import dataclass

import numpy as np
from skimage.morphology import skeletonize


@dataclass
class SkeletonPath:
    skeleton: np.ndarray
    path: np.ndarray
    pixel_length: float


def _neighbors(point: tuple[int, int], points: set[tuple[int, int]]) -> list[tuple[tuple[int, int], float]]:
    y, x = point
    result: list[tuple[tuple[int, int], float]] = []
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dy == 0 and dx == 0:
                continue
            candidate = (y + dy, x + dx)
            if candidate in points:
                result.append((candidate, float(np.sqrt(2.0) if dy != 0 and dx != 0 else 1.0)))
    return result


def _prune_short_spurs(points: set[tuple[int, int]], threshold: float = 2.0) -> set[tuple[int, int]]:
    changed = True
    output = set(points)
    while changed:
        changed = False
        endpoints = [point for point in output if len(_neighbors(point, output)) == 1]
        for endpoint in endpoints:
            path = [endpoint]
            previous: tuple[int, int] | None = None
            current = endpoint
            length = 0.0
            while True:
                options = [(item, weight) for item, weight in _neighbors(current, output) if item != previous]
                if len(options) != 1:
                    break
                next_point, weight = options[0]
                path.append(next_point)
                length += weight
                previous, current = current, next_point
                if len(_neighbors(current, output)) != 2:
                    break
            if len(_neighbors(current, output)) > 2 and length <= threshold:
                for point in path[:-1]:
                    output.discard(point)
                changed = True
    return output


def _dijkstra(start: tuple[int, int], points: set[tuple[int, int]]) -> tuple[dict[tuple[int, int], float], dict[tuple[int, int], tuple[int, int]]]:
    distances = {start: 0.0}
    parents: dict[tuple[int, int], tuple[int, int]] = {}
    queue: list[tuple[float, tuple[int, int]]] = [(0.0, start)]
    while queue:
        distance, point = heapq.heappop(queue)
        if distance != distances.get(point):
            continue
        for candidate, weight in _neighbors(point, points):
            value = distance + weight
            if value < distances.get(candidate, float("inf")):
                distances[candidate] = value
                parents[candidate] = point
                heapq.heappush(queue, (value, candidate))
    return distances, parents


def _components(points: set[tuple[int, int]]) -> list[set[tuple[int, int]]]:
    remaining = set(points)
    result: list[set[tuple[int, int]]] = []
    while remaining:
        root = next(iter(remaining))
        component = {root}
        stack = [root]
        remaining.remove(root)
        while stack:
            point = stack.pop()
            for candidate, _ in _neighbors(point, points):
                if candidate in remaining:
                    remaining.remove(candidate)
                    component.add(candidate)
                    stack.append(candidate)
        result.append(component)
    return result


def longest_skeleton_path(mask: np.ndarray) -> SkeletonPath:
    if mask.ndim != 2:
        raise ValueError("mask must be two dimensional")
    skeleton = skeletonize(mask.astype(bool))
    original_points = {tuple(int(value) for value in point) for point in np.argwhere(skeleton)}
    points = _prune_short_spurs(original_points)
    clean = np.zeros_like(mask, dtype=np.uint8)
    for y, x in points:
        clean[y, x] = 1
    if not points:
        return SkeletonPath(clean, np.zeros((0, 2), dtype=np.int32), 0.0)
    best_length = -1.0
    best_path: list[tuple[int, int]] = []
    for component in _components(points):
        endpoints = [point for point in component if len(_neighbors(point, component)) == 1]
        if endpoints:
            for start in endpoints:
                distances, parents = _dijkstra(start, component)
                for end in endpoints:
                    if distances.get(end, -1.0) > best_length:
                        path = [end]
                        while path[-1] != start:
                            path.append(parents[path[-1]])
                        best_length = distances[end]
                        best_path = list(reversed(path))
        else:
            start = next(iter(component))
            first_distances, _ = _dijkstra(start, component)
            first = max(first_distances, key=first_distances.get)
            second_distances, parents = _dijkstra(first, component)
            second = max(second_distances, key=second_distances.get)
            path = [second]
            while path[-1] != first:
                path.append(parents[path[-1]])
            if second_distances[second] > best_length:
                best_length = second_distances[second]
                best_path = list(reversed(path))
    return SkeletonPath(clean, np.asarray(best_path, dtype=np.int32), max(best_length, 0.0))
