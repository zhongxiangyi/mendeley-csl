from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


def save_overlay(image_rgb: np.ndarray, mask: np.ndarray, output_path: Path, color: tuple[int, int, int]) -> None:
    overlay = image_rgb.copy()
    overlay[mask.astype(bool)] = color
    combined = cv2.addWeighted(image_rgb, 0.65, overlay, 0.35, 0.0)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output_path), cv2.cvtColor(combined, cv2.COLOR_RGB2BGR)):
        raise IOError(f"failed to write {output_path}")


def save_crack_visuals(mask: np.ndarray, skeleton: np.ndarray, width_lines: list[list[list[float]]], output_skeleton: Path, output_lines: Path, output_heatmap: Path) -> None:
    canvas = np.zeros((*mask.shape, 3), dtype=np.uint8)
    canvas[mask.astype(bool)] = (90, 90, 90)
    canvas[skeleton.astype(bool)] = (255, 255, 0)
    line_canvas = canvas.copy()
    for line in width_lines:
        first = tuple(int(round(value)) for value in line[0])
        second = tuple(int(round(value)) for value in line[1])
        cv2.line(line_canvas, first, second, (0, 255, 0), 1)
    distance = cv2.distanceTransform(mask.astype(np.uint8), cv2.DIST_L2, 5)
    normalized = cv2.normalize(distance, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    heatmap = cv2.applyColorMap(normalized, cv2.COLORMAP_JET)
    for path, value in ((output_skeleton, canvas), (output_lines, line_canvas), (output_heatmap, heatmap)):
        path.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(path), value):
            raise IOError(f"failed to write {path}")


def save_spalling_visuals(mask: np.ndarray, output_contour: Path, output_area: Path) -> None:
    canvas = np.zeros((*mask.shape, 3), dtype=np.uint8)
    contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(canvas, contours, -1, (0, 255, 255), 1)
    area = np.zeros_like(canvas)
    area[mask.astype(bool)] = (255, 100, 0)
    for path, value in ((output_contour, canvas), (output_area, area)):
        path.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(path), value):
            raise IOError(f"failed to write {path}")
