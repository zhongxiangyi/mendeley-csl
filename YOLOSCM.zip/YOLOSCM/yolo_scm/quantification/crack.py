from __future__ import annotations

from typing import Any

import numpy as np
from scipy.ndimage import distance_transform_edt

from yolo_scm.calibration.scale import ImageScale
from yolo_scm.quantification.skeleton_graph import SkeletonPath, longest_skeleton_path


def _degree(point: tuple[int, int], skeleton: np.ndarray) -> int:
    y, x = point
    y0, y1 = max(0, y - 1), min(skeleton.shape[0], y + 2)
    x0, x1 = max(0, x - 1), min(skeleton.shape[1], x + 2)
    return int(skeleton[y0:y1, x0:x1].sum()) - 1


def _statistics(values: np.ndarray) -> dict[str, float | int | None]:
    if values.size == 0:
        return {"maximum_width_mm": None, "average_width_mm": None, "median_width_mm": None, "standard_deviation_width_mm": None, "valid_width_point_count": 0}
    return {"maximum_width_mm": float(values.max()), "average_width_mm": float(values.mean()), "median_width_mm": float(np.median(values)), "standard_deviation_width_mm": float(values.std(ddof=0)), "valid_width_point_count": int(values.size)}


def _pixel_statistics(values: np.ndarray) -> dict[str, float | int | None]:
    if values.size == 0:
        return {"maximum_width_pixels": None, "average_width_pixels": None, "median_width_pixels": None, "standard_deviation_width_pixels": None, "valid_width_point_count": 0}
    return {"maximum_width_pixels": float(values.max()), "average_width_pixels": float(values.mean()), "median_width_pixels": float(np.median(values)), "standard_deviation_width_pixels": float(values.std(ddof=0)), "valid_width_point_count": int(values.size)}


def _direction(point_index: int, path: np.ndarray, window: int) -> np.ndarray | None:
    start = max(0, point_index - window // 2)
    end = min(path.shape[0], point_index + window // 2 + 1)
    coordinates = path[start:end].astype(np.float64)
    if coordinates.shape[0] < 2:
        return None
    centered = coordinates - coordinates.mean(axis=0)
    _, _, vectors = np.linalg.svd(centered, full_matrices=False)
    direction = vectors[0]
    norm = np.linalg.norm(direction)
    return direction / norm if norm > 0 else None


def quantify_crack(mask: np.ndarray, scale: ImageScale | None, environment: str = "laboratory", pca_window_size: int = 15, minimum_reliable_width_pixels: float = 3.0) -> dict[str, Any]:
    if mask.ndim != 2:
        raise ValueError("crack mask must be two dimensional")
    binary = mask.astype(bool)
    path_result: SkeletonPath = longest_skeleton_path(binary)
    distance = distance_transform_edt(binary)
    widths_pixels: list[float] = []
    width_lines: list[list[list[float]]] = []
    for index, point in enumerate(path_result.path):
        y, x = int(point[0]), int(point[1])
        if _degree((y, x), path_result.skeleton) > 2:
            continue
        width_pixels = 2.0 * float(distance[y, x])
        widths_pixels.append(width_pixels)
        direction = _direction(index, path_result.path, pca_window_size)
        if direction is not None:
            perpendicular = np.asarray([-direction[1], direction[0]])
            radius = float(distance[y, x])
            width_lines.append([[float(x - perpendicular[1] * radius), float(y - perpendicular[0] * radius)], [float(x + perpendicular[1] * radius), float(y + perpendicular[0] * radius)]])
    widths = np.asarray(widths_pixels, dtype=np.float64)
    pixel_statistics = _pixel_statistics(widths)
    reliable_pixels = widths[widths >= minimum_reliable_width_pixels]
    if scale is None:
        return {"pixel_length": float(path_result.pixel_length), "crack_length_mm": None, "all_width_statistics": _statistics(np.asarray([], dtype=np.float64)), "reliable_width_statistics": _statistics(np.asarray([], dtype=np.float64)), "all_width_statistics_pixels": pixel_statistics, "reliable_width_statistics_pixels": _pixel_statistics(reliable_pixels), "reliable_flag": False, "skeleton": path_result.skeleton, "path": path_result.path, "width_lines": width_lines}
    widths_mm = widths * scale.isotropic_mm_per_pixel
    threshold_mm = 0.20 if environment == "laboratory" else 0.30
    reliable = widths_mm[widths >= minimum_reliable_width_pixels]
    result = {"pixel_length": float(path_result.pixel_length), "crack_length_mm": float(path_result.pixel_length * scale.isotropic_mm_per_pixel), "all_width_statistics": _statistics(widths_mm), "reliable_width_statistics": _statistics(reliable), "all_width_statistics_pixels": pixel_statistics, "reliable_width_statistics_pixels": _pixel_statistics(reliable_pixels), "reliable_flag": bool(reliable.size > 0 and float(np.max(reliable)) >= threshold_mm), "skeleton": path_result.skeleton, "path": path_result.path, "width_lines": width_lines}
    return result
