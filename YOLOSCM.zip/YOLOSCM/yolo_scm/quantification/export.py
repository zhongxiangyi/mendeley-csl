from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import numpy as np


def _serialize(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(key): _serialize(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_serialize(item) for item in value]
    if isinstance(value, tuple):
        return [_serialize(item) for item in value]
    return value


def export_measurements(records: list[dict[str, Any]], output_directory: Path) -> tuple[Path, Path, Path]:
    output_directory.mkdir(parents=True, exist_ok=True)
    ordered = sorted(records, key=lambda value: (str(value["image_id"]), int(value["instance_id"])))
    json_path = output_directory / "measurements.json"
    csv_path = output_directory / "measurements.csv"
    rejected_path = output_directory / "rejected_measurements.csv"
    json_path.write_text(json.dumps(_serialize(ordered), ensure_ascii=False, indent=2), encoding="utf-8")
    fields = ["image_id", "instance_id", "class_id", "class_name", "confidence", "bbox_xyxy", "mask_pixel_count", "pixel_scale_x_mm", "pixel_scale_y_mm", "crack_length_pixels", "maximum_crack_width_pixels", "average_crack_width_pixels", "median_crack_width_pixels", "spalling_pixel_area", "crack_length_mm", "maximum_crack_width_mm", "average_crack_width_mm", "median_crack_width_mm", "spalling_area_mm2", "spalling_area_cm2", "perimeter_mm", "reliable", "reliability_status", "rejection_reasons", "calibration_residual_percent", "calibration_validation_status", "homography_fitting_residual_percent", "surface_angle_deg"]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for record in ordered:
            row = _serialize(record)
            row["bbox_xyxy"] = json.dumps(row.get("bbox_xyxy"), ensure_ascii=False)
            row["rejection_reasons"] = json.dumps(row.get("rejection_reasons"), ensure_ascii=False)
            writer.writerow(row)
    with rejected_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for record in ordered:
            if not bool(record["reliable"]):
                row = _serialize(record)
                row["bbox_xyxy"] = json.dumps(row.get("bbox_xyxy"), ensure_ascii=False)
                row["rejection_reasons"] = json.dumps(row.get("rejection_reasons"), ensure_ascii=False)
                writer.writerow(row)
    return csv_path, json_path, rejected_path
