from __future__ import annotations

import random
from typing import Any

import cv2
import numpy as np


class ImageTransform:
    def __init__(self, image_size: int, training: bool, values: dict[str, Any] | None = None, defaults: dict[str, Any] | None = None) -> None:
        self.image_size = image_size
        self.training = training
        self.values = values or {}
        self.defaults = defaults or {}

    def __call__(self, image: np.ndarray, masks: list[np.ndarray]) -> dict[str, Any]:
        output = image.copy()
        transformed_masks = [mask.copy() for mask in masks]
        if self.training:
            output, transformed_masks = self._geometric(output, transformed_masks)
            output = self._color(output)
        output = cv2.resize(output, (self.image_size, self.image_size), interpolation=cv2.INTER_LINEAR)
        transformed_masks = [cv2.resize(mask, (self.image_size, self.image_size), interpolation=cv2.INTER_NEAREST) for mask in transformed_masks]
        return {"image": output, "masks": transformed_masks}

    def _geometric(self, image: np.ndarray, masks: list[np.ndarray]) -> tuple[np.ndarray, list[np.ndarray]]:
        if random.random() < float(self.values["horizontal_flip"]):
            image = cv2.flip(image, 1)
            masks = [cv2.flip(mask, 1) for mask in masks]
        if random.random() < float(self.values["vertical_flip"]):
            image = cv2.flip(image, 0)
            masks = [cv2.flip(mask, 0) for mask in masks]
        height, width = image.shape[:2]
        angle = random.uniform(*[float(item) for item in self.values["rotation"]])
        scale = random.uniform(*[float(item) for item in self.values["scale"]])
        translation = float(self.values["translation"])
        matrix = cv2.getRotationMatrix2D((width / 2.0, height / 2.0), angle, scale)
        matrix[:, 2] += (random.uniform(-translation, translation) * width, random.uniform(-translation, translation) * height)
        return cv2.warpAffine(image, matrix, (width, height), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(114, 114, 114)), [cv2.warpAffine(mask, matrix, (width, height), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT) for mask in masks]

    def _color(self, image: np.ndarray) -> np.ndarray:
        brightness = random.uniform(-float(self.values["brightness"]), float(self.values["brightness"]))
        contrast = 1.0 + random.uniform(-float(self.values["contrast"]), float(self.values["contrast"]))
        output = np.clip(image.astype(np.float32) * contrast + 255.0 * brightness, 0, 255).astype(np.uint8)
        hsv = cv2.cvtColor(output, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 0] = (hsv[:, :, 0] + random.uniform(-1.0, 1.0) * 179.0 * float(self.defaults["hsv_h"])) % 180.0
        hsv[:, :, 1] = np.clip(hsv[:, :, 1] * (1.0 + random.uniform(-1.0, 1.0) * float(self.defaults["hsv_s"])), 0, 255)
        hsv[:, :, 2] = np.clip(hsv[:, :, 2] * (1.0 + random.uniform(-1.0, 1.0) * float(self.defaults["hsv_v"])), 0, 255)
        output = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        if random.random() < float(self.values["gaussian_blur"]):
            output = cv2.GaussianBlur(output, (5, 5), 0)
        if random.random() < float(self.values["gaussian_noise"]):
            output = np.clip(output.astype(np.float32) + np.random.normal(0.0, 8.0, output.shape), 0, 255).astype(np.uint8)
        return output


def training_augmentation(config: dict[str, Any], implementation_defaults: dict[str, Any], image_size: int) -> ImageTransform:
    return ImageTransform(image_size, True, config["augmentation"], implementation_defaults)


def evaluation_augmentation(image_size: int) -> ImageTransform:
    return ImageTransform(image_size, False)
