from __future__ import annotations

import json
from pathlib import Path


CLASS_MAP: dict[str, int] = {"crack": 0, "spalling": 1}


def convert_xanylabeling_json(source: Path, destination: Path) -> int:
    with source.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    width = float(payload.get("imageWidth", 0))
    height = float(payload.get("imageHeight", 0))
    if width <= 0 or height <= 0:
        raise ValueError("imageWidth and imageHeight must be positive")
    lines: list[str] = []
    for shape in payload.get("shapes", []):
        label = str(shape.get("label", "")).strip().lower()
        points = shape.get("points", [])
        if label not in CLASS_MAP:
            raise ValueError(f"unsupported label {label}")
        if len(points) < 3:
            raise ValueError("each shape must contain at least three points")
        normalized: list[str] = []
        for point in points:
            if not isinstance(point, list) or len(point) != 2:
                raise ValueError("invalid point")
            x, y = float(point[0]), float(point[1])
            if x < 0 or y < 0 or x > width or y > height:
                raise ValueError("point outside image")
            normalized.extend((f"{x / width:.8f}", f"{y / height:.8f}"))
        lines.append(" ".join([str(CLASS_MAP[label]), *normalized]))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return len(lines)
