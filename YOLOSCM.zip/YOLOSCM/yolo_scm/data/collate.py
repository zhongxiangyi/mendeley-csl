from __future__ import annotations

from typing import Any

import torch


def collate_instances(batch: list[dict[str, Any]]) -> dict[str, Any]:
    if not batch:
        raise ValueError("cannot collate an empty batch")
    return {"images": torch.stack([item["image"] for item in batch], dim=0), "targets": [item["target"] for item in batch], "image_paths": [item["image_path"] for item in batch], "original_shapes": [item["original_shape"] for item in batch]}
