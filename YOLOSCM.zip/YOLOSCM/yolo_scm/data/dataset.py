from __future__ import annotations

import random
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
import yaml
from torch.utils.data import Dataset

from yolo_scm.data.augment import evaluation_augmentation, training_augmentation


class YoloInstanceDataset(Dataset[dict[str, Any]]):
    def __init__(self, data_config: Path, split: str, paper_config: Path, train: bool = False, defaults_config: Path = Path("configs/implementation_defaults.yaml")) -> None:
        with data_config.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle)
        with paper_config.open("r", encoding="utf-8") as handle:
            paper = yaml.safe_load(handle)
        with defaults_config.open("r", encoding="utf-8") as handle:
            defaults = yaml.safe_load(handle)
        if split not in {"train", "val", "test", "measurement_val"}:
            raise ValueError("invalid dataset split")
        root = Path(data["path"])
        split_path = root / str(data[split])
        if not split_path.exists():
            raise FileNotFoundError(split_path)
        self.images = sorted(path for path in split_path.rglob("*") if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"})
        if not self.images:
            raise ValueError(f"no images found in {split_path}")
        self.image_size = int(paper["training"]["image_size"])
        self.train = train
        self.mosaic_probability = float(paper["augmentation"]["mosaic"]) if train else 0.0
        implementation_defaults = defaults.get("implementation_defaults", {})
        self.transform = training_augmentation(paper, implementation_defaults, self.image_size) if train else evaluation_augmentation(self.image_size)

    def __len__(self) -> int:
        return len(self.images)

    def _label_path(self, image_path: Path) -> Path:
        parts = list(image_path.parts)
        try:
            index = parts.index("images")
            parts[index] = "labels"
            label = Path(*parts).with_suffix(".txt")
        except ValueError:
            label = image_path.with_suffix(".txt")
        return label

    def _read(self, image_path: Path) -> tuple[np.ndarray, list[int], list[np.ndarray]]:
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f"unable to read image {image_path}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        labels: list[int] = []
        masks: list[np.ndarray] = []
        label_path = self._label_path(image_path)
        if not label_path.exists():
            return image, labels, masks
        height, width = image.shape[:2]
        for line in label_path.read_text(encoding="utf-8").splitlines():
            values = line.split()
            if len(values) < 7 or (len(values) - 1) % 2 != 0:
                raise ValueError(f"invalid segmentation label in {label_path}")
            class_id = int(values[0])
            if class_id not in {0, 1}:
                raise ValueError(f"invalid class id in {label_path}")
            coordinates = np.asarray([float(value) for value in values[1:]], dtype=np.float32).reshape(-1, 2)
            if np.any(coordinates < 0.0) or np.any(coordinates > 1.0):
                raise ValueError(f"non-normalized polygon in {label_path}")
            polygon = np.rint(coordinates * np.asarray([width - 1, height - 1], dtype=np.float32)).astype(np.int32)
            mask = np.zeros((height, width), dtype=np.uint8)
            cv2.fillPoly(mask, [polygon], 1)
            if int(mask.sum()) == 0:
                raise ValueError(f"empty polygon in {label_path}")
            labels.append(class_id)
            masks.append(mask)
        return image, labels, masks

    def _mosaic(self, index: int) -> tuple[np.ndarray, list[int], list[np.ndarray]]:
        selected = [index] + [random.randrange(len(self.images)) for _ in range(3)]
        canvas = np.zeros((self.image_size * 2, self.image_size * 2, 3), dtype=np.uint8)
        labels: list[int] = []
        masks: list[np.ndarray] = []
        for position, sample_index in enumerate(selected):
            image, sample_labels, sample_masks = self._read(self.images[sample_index])
            resized = cv2.resize(image, (self.image_size, self.image_size), interpolation=cv2.INTER_LINEAR)
            row, column = divmod(position, 2)
            y0, x0 = row * self.image_size, column * self.image_size
            canvas[y0 : y0 + self.image_size, x0 : x0 + self.image_size] = resized
            for label, mask in zip(sample_labels, sample_masks):
                resized_mask = cv2.resize(mask, (self.image_size, self.image_size), interpolation=cv2.INTER_NEAREST)
                expanded = np.zeros((self.image_size * 2, self.image_size * 2), dtype=np.uint8)
                expanded[y0 : y0 + self.image_size, x0 : x0 + self.image_size] = resized_mask
                labels.append(label)
                masks.append(expanded)
        return canvas, labels, masks

    def __getitem__(self, index: int) -> dict[str, Any]:
        if self.train and random.random() < self.mosaic_probability:
            image, labels, masks = self._mosaic(index)
        else:
            image, labels, masks = self._read(self.images[index])
        original_shape = image.shape[:2]
        transformed = self.transform(image=image, masks=masks)
        transformed_image = transformed["image"]
        transformed_masks = [np.asarray(mask, dtype=np.uint8) for mask in transformed["masks"]]
        boxes: list[list[float]] = []
        valid_labels: list[int] = []
        valid_masks: list[np.ndarray] = []
        for label, mask in zip(labels, transformed_masks):
            ys, xs = np.nonzero(mask)
            if len(xs) == 0:
                continue
            boxes.append([float(xs.min()), float(ys.min()), float(xs.max() + 1), float(ys.max() + 1)])
            valid_labels.append(label)
            valid_masks.append(mask)
        tensor_image = torch.from_numpy(np.ascontiguousarray(transformed_image.transpose(2, 0, 1))).float() / 255.0
        tensor_masks = torch.from_numpy(np.stack(valid_masks, axis=0)) if valid_masks else torch.zeros((0, self.image_size, self.image_size), dtype=torch.uint8)
        tensor_boxes = torch.tensor(boxes, dtype=torch.float32) if boxes else torch.zeros((0, 4), dtype=torch.float32)
        return {"image": tensor_image, "target": {"boxes": tensor_boxes, "labels": torch.tensor(valid_labels, dtype=torch.long), "masks": tensor_masks}, "image_path": str(self.images[index]), "original_shape": original_shape}
