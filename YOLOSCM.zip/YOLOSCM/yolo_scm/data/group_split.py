from __future__ import annotations

from pathlib import Path

import pandas as pd
from sklearn.model_selection import GroupShuffleSplit


def create_group_split(metadata_path: Path, output_path: Path, seed: int = 2022, train_ratio: float = 0.7, val_ratio: float = 0.2, test_ratio: float = 0.1) -> pd.DataFrame:
    if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-9:
        raise ValueError("split ratios must sum to 1")
    metadata = pd.read_csv(metadata_path)
    required = {"image", "group_id", "source", "scene", "specimen_id"}
    missing = required.difference(metadata.columns)
    if missing:
        raise ValueError(f"missing metadata fields: {sorted(missing)}")
    first = GroupShuffleSplit(n_splits=1, train_size=train_ratio, random_state=seed)
    train_indices, remainder_indices = next(first.split(metadata, groups=metadata["group_id"]))
    remainder = metadata.iloc[remainder_indices]
    val_fraction = val_ratio / (val_ratio + test_ratio)
    second = GroupShuffleSplit(n_splits=1, train_size=val_fraction, random_state=seed + 1)
    val_local, test_local = next(second.split(remainder, groups=remainder["group_id"]))
    result = metadata.copy()
    result["split"] = "test"
    result.loc[metadata.index[train_indices], "split"] = "train"
    result.loc[remainder.index[val_local], "split"] = "val"
    train_groups = set(result.loc[result["split"] == "train", "group_id"])
    val_groups = set(result.loc[result["split"] == "val", "group_id"])
    if train_groups.intersection(val_groups) or train_groups.intersection(set(result.loc[result["split"] == "test", "group_id"])) or val_groups.intersection(set(result.loc[result["split"] == "test", "group_id"])):
        raise RuntimeError("group leakage detected")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False)
    return result
