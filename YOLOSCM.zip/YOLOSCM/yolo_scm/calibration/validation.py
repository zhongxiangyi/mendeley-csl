from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from yolo_scm.calibration.scale import ImageScale, scale_quality_range


@dataclass
class CalibrationDecision:
    reliable: bool
    status: str
    reasons: list[str]


def validate_measurement(metadata: dict[str, Any], scale: ImageScale | None, max_residual_percent: float = 2.0, max_surface_angle_deg: float = 15.0) -> CalibrationDecision:
    reasons: list[str] = []
    angle = float(metadata.get("surface_angle_deg", 90.0))
    provisional = False
    if scale is None:
        reasons.append("missing_or_invalid_scale")
    elif scale.calibration_validation_status == "independently_validated":
        if scale.residual_percent is None:
            reasons.append("independent_calibration_residual_unavailable")
        elif scale.residual_percent >= max_residual_percent:
            reasons.append("scale_residual_percent_not_below_limit")
    elif scale.calibration_validation_status == "fitted_only":
        provisional = True
    else:
        reasons.append("calibration_validation_unavailable")
    if angle > max_surface_angle_deg:
        reasons.append("surface_angle_exceeds_limit")
    if not bool(metadata.get("calibration_object_complete", True)):
        reasons.append("calibration_object_incomplete")
    if not bool(metadata.get("approximately_coplanar", True)):
        reasons.append("damage_and_calibration_object_not_coplanar")
    if bool(metadata.get("severe_out_of_plane_curvature", False)):
        reasons.append("severe_out_of_plane_curvature")
    if bool(metadata.get("severe_occlusion", False)):
        reasons.append("severe_occlusion")
    if scale is not None and not scale_quality_range(scale, str(metadata.get("environment", "laboratory"))):
        reasons.append("scale_outside_quality_check_range")
    if reasons:
        return CalibrationDecision(False, "pixel_only", reasons)
    if provisional:
        if bool(metadata.get("allow_provisional_calibration", False)):
            return CalibrationDecision(True, "provisional_calibration", [])
        return CalibrationDecision(False, "provisional_calibration", ["independent_calibration_validation_required"])
    return CalibrationDecision(True, "accepted", [])
