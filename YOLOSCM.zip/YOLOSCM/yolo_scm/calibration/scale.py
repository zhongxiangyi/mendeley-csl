from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Sequence

import numpy as np


CalibrationValidationStatus = Literal["fitted_only", "independently_validated", "unavailable"]


@dataclass
class ImageScale:
    x_mm_per_pixel: float
    y_mm_per_pixel: float
    residual_percent: float | None
    mode: str
    calibration_validation_status: CalibrationValidationStatus = "independently_validated"
    diagnostics: dict[str, Any] = field(default_factory=dict)

    @property
    def isotropic_mm_per_pixel(self) -> float:
        return float((self.x_mm_per_pixel + self.y_mm_per_pixel) / 2.0)


def _length(points: Sequence[Sequence[float]]) -> float:
    if len(points) != 2 or any(len(point) != 2 for point in points):
        raise ValueError("a calibration segment must contain exactly two xy points")
    value = float(np.linalg.norm(np.asarray(points[1], dtype=np.float64) - np.asarray(points[0], dtype=np.float64)))
    if value <= 0:
        raise ValueError("calibration pixel length must be positive")
    return value


def _segments(segments: Sequence[dict[str, Any]]) -> tuple[np.ndarray, np.ndarray]:
    pixels = np.asarray([_length(item["points"]) for item in segments], dtype=np.float64)
    physical = np.asarray([float(item["reference_length_mm"]) for item in segments], dtype=np.float64)
    if np.any(physical <= 0):
        raise ValueError("reference lengths must be positive")
    return pixels, physical


def fit_ruler_scale(segments: Sequence[dict[str, Any]], verification_segments: Sequence[dict[str, Any]] | None = None) -> ImageScale:
    if not segments:
        raise ValueError("at least one ruler segment is required")
    pixels, physical = _segments(segments)
    scale = float(np.dot(pixels, physical) / np.dot(pixels, pixels))
    estimated_fit = scale * pixels
    fit_residual = estimated_fit - physical
    diagnostics: dict[str, Any] = {"segment_count": len(segments), "fitted_lengths_mm": estimated_fit.tolist(), "fitting_absolute_residuals_mm": np.abs(fit_residual).tolist(), "fitting_rmse_mm": float(np.sqrt(np.mean(fit_residual**2)))}
    if not verification_segments:
        return ImageScale(scale, scale, None, "ruler", "fitted_only", diagnostics)
    check_pixels, check_physical = _segments(verification_segments)
    estimated = scale * check_pixels
    residual = estimated - check_physical
    rmse = float(np.sqrt(np.mean(residual**2)))
    percent = float(100.0 * rmse / check_physical.mean())
    diagnostics.update({"verification_segment_count": len(verification_segments), "estimated_lengths_mm": estimated.tolist(), "absolute_residuals_mm": np.abs(residual).tolist(), "relative_residuals": (np.abs(residual) / check_physical).tolist(), "rmse_mm": rmse})
    return ImageScale(scale, scale, percent, "ruler", "independently_validated", diagnostics)


def ruler_scale(points: Sequence[Sequence[float]], reference_length_mm: float) -> ImageScale:
    return fit_ruler_scale([{ "points": [list(point) for point in points], "reference_length_mm": reference_length_mm }])


def scale_from_metadata(metadata: dict[str, Any]) -> ImageScale:
    if metadata.get("mode") != "ruler":
        raise ValueError("ruler metadata mode is required")
    if "segments" in metadata:
        segments = metadata["segments"]
        verification = metadata.get("verification_segments", [])
        if not isinstance(segments, list) or not isinstance(verification, list):
            raise ValueError("segments and verification_segments must be lists")
        return fit_ruler_scale(segments, verification)
    return ruler_scale(metadata["points"], float(metadata["reference_length_mm"]))


def scale_quality_range(scale: ImageScale, environment: str) -> bool:
    ranges = {"laboratory": (0.035, 0.080), "field": (0.060, 0.120)}
    if environment not in ranges:
        raise ValueError("environment must be laboratory or field")
    lower, upper = ranges[environment]
    return lower <= scale.isotropic_mm_per_pixel <= upper
