from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import yaml

from yolo_scm.calibration.schema import CameraCalibration


def calibrate_camera(image_paths: list[Path], square_size_mm: float, output_path: Path, columns: int = 9, rows: int = 6, required_views: int = 20) -> CameraCalibration:
    if square_size_mm <= 0:
        raise ValueError("square_size_mm must be positive")
    if len(image_paths) < required_views:
        raise ValueError(f"at least {required_views} calibration images are required")
    object_template = np.zeros((columns * rows, 3), dtype=np.float32)
    object_template[:, :2] = np.mgrid[0:columns, 0:rows].T.reshape(-1, 2) * square_size_mm
    objects: list[np.ndarray] = []
    corners_list: list[np.ndarray] = []
    image_size: tuple[int, int] | None = None
    for image_path in image_paths:
        image = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise ValueError(f"unable to read calibration image {image_path}")
        found, corners = cv2.findChessboardCorners(image, (columns, rows))
        if not found or corners is None:
            continue
        refined = cv2.cornerSubPix(image, corners, (11, 11), (-1, -1), (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001))
        objects.append(object_template)
        corners_list.append(refined)
        image_size = (image.shape[1], image.shape[0])
    if len(objects) < required_views or image_size is None:
        raise ValueError(f"only {len(objects)} valid checkerboard views found, required {required_views}")
    _, matrix, distortion, rotations, translations = cv2.calibrateCamera(objects, corners_list, image_size, None, None)
    errors: list[float] = []
    for points, rotation, translation in zip(objects, rotations, translations):
        projected, _ = cv2.projectPoints(points, rotation, translation, matrix, distortion)
        observed = corners_list[len(errors)]
        errors.append(float(cv2.norm(observed, projected, cv2.NORM_L2) / len(projected)))
    result = CameraCalibration(matrix.tolist(), distortion.reshape(-1).tolist(), image_size, float(np.mean(errors)), (columns, rows), square_size_mm)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(result.to_dict(), handle, sort_keys=False)
    return result


def load_camera_calibration(path: Path) -> CameraCalibration:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    required = {"camera_matrix", "distortion_coefficients", "image_size", "reprojection_error", "checkerboard_size", "square_size_mm"}
    if not isinstance(value, dict) or required.difference(value):
        raise ValueError("invalid camera calibration YAML")
    return CameraCalibration([[float(item) for item in row] for row in value["camera_matrix"]], [float(item) for item in value["distortion_coefficients"]], tuple(int(item) for item in value["image_size"]), float(value["reprojection_error"]), tuple(int(item) for item in value["checkerboard_size"]), float(value["square_size_mm"]))


def undistort(image: np.ndarray, calibration: CameraCalibration) -> np.ndarray:
    matrix = np.asarray(calibration.camera_matrix, dtype=np.float64)
    distortion = np.asarray(calibration.distortion_coefficients, dtype=np.float64)
    return cv2.undistort(image, matrix, distortion)
