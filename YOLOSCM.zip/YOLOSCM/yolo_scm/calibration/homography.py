from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import cv2
import numpy as np

from yolo_scm.calibration.scale import ImageScale


@dataclass
class HomographyResult:
    matrix: np.ndarray
    translation: np.ndarray
    total_matrix: np.ndarray
    scale: ImageScale
    output_size: tuple[int, int]
    bounds: tuple[float, float, float, float]
    homography_fitting_residual_percent: float
    homography_reprojection_error: float
    calibration_validation_status: str


def order_corners(corners: Sequence[Sequence[float]]) -> np.ndarray:
    array = np.asarray(corners, dtype=np.float32)
    if array.shape != (4, 2):
        raise ValueError("marker requires four xy corners")
    sums = array.sum(axis=1)
    differences = np.diff(array, axis=1).reshape(-1)
    ordered = np.zeros((4, 2), dtype=np.float32)
    ordered[0] = array[np.argmin(sums)]
    ordered[2] = array[np.argmax(sums)]
    ordered[1] = array[np.argmin(differences)]
    ordered[3] = array[np.argmax(differences)]
    if abs(float(cv2.contourArea(ordered))) < 1e-6:
        raise ValueError("marker corners are degenerate")
    return ordered


def _transform(points: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    return cv2.perspectiveTransform(points.reshape(1, -1, 2).astype(np.float32), matrix).reshape(-1, 2)


def _validation_residual(matrix: np.ndarray, validation_points: Sequence[Mapping[str, Sequence[float]]], pixels_per_mm: float, marker_width_mm: float, marker_height_mm: float) -> tuple[float, float]:
    image_points: list[Sequence[float]] = []
    physical_points: list[Sequence[float]] = []
    for item in validation_points:
        image_point = item.get("image_point")
        physical_point = item.get("physical_point_mm")
        if not isinstance(image_point, Sequence) or not isinstance(physical_point, Sequence) or len(image_point) != 2 or len(physical_point) != 2:
            raise ValueError("each validation point requires image_point and physical_point_mm")
        image_points.append(image_point)
        physical_points.append(physical_point)
    if not image_points:
        raise ValueError("validation_points must not be empty")
    mapped = _transform(np.asarray(image_points, dtype=np.float32), matrix) / pixels_per_mm
    reference = np.asarray(physical_points, dtype=np.float64)
    errors = np.linalg.norm(mapped - reference, axis=1)
    rmse = float(np.sqrt(np.mean(errors**2)))
    return float(100.0 * rmse / ((marker_width_mm + marker_height_mm) / 2.0)), rmse


def marker_homography(corners: Sequence[Sequence[float]], image_shape: tuple[int, int] | None = None, damage_points: np.ndarray | None = None, marker_width_mm: float = 25.0, marker_height_mm: float = 30.0, pixels_per_mm: float = 10.0, validation_points: Sequence[Mapping[str, Sequence[float]]] | None = None) -> HomographyResult:
    if marker_width_mm <= 0 or marker_height_mm <= 0 or pixels_per_mm <= 0:
        raise ValueError("marker dimensions and pixels_per_mm must be positive")
    source = order_corners(corners)
    marker_pixels = np.asarray([[0.0, 0.0], [marker_width_mm * pixels_per_mm, 0.0], [marker_width_mm * pixels_per_mm, marker_height_mm * pixels_per_mm], [0.0, marker_height_mm * pixels_per_mm]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(source, marker_pixels)
    transformed_marker = _transform(source, matrix)
    edge_lengths = np.asarray([np.linalg.norm(transformed_marker[(index + 1) % 4] - transformed_marker[index]) / pixels_per_mm for index in range(4)], dtype=np.float64)
    expected = np.asarray([marker_width_mm, marker_height_mm, marker_width_mm, marker_height_mm], dtype=np.float64)
    fitting_residual_percent = float(100.0 * np.mean(np.abs(edge_lengths - expected) / expected))
    reprojection = float(np.mean(np.linalg.norm(transformed_marker - marker_pixels, axis=1)) / pixels_per_mm)
    canvas_points: list[np.ndarray] = [source]
    if image_shape is not None:
        height, width = image_shape
        if height <= 0 or width <= 0:
            raise ValueError("image_shape must be positive")
        canvas_points.append(np.asarray([[0.0, 0.0], [width - 1.0, 0.0], [width - 1.0, height - 1.0], [0.0, height - 1.0]], dtype=np.float32))
    if damage_points is not None:
        points = np.asarray(damage_points, dtype=np.float32)
        if points.ndim != 2 or points.shape[1] != 2:
            raise ValueError("damage_points must have shape Nx2")
        canvas_points.append(points)
    mapped = np.concatenate([_transform(points, matrix) for points in canvas_points], axis=0)
    minimum = mapped.min(axis=0)
    maximum = mapped.max(axis=0)
    translation = np.asarray([[1.0, 0.0, -minimum[0]], [0.0, 1.0, -minimum[1]], [0.0, 0.0, 1.0]], dtype=np.float32)
    total = translation @ matrix
    output_width = max(1, int(np.ceil(maximum[0] - minimum[0] + 1.0)))
    output_height = max(1, int(np.ceil(maximum[1] - minimum[1] + 1.0)))
    diagnostics: dict[str, Any] = {"edge_lengths_mm": edge_lengths.tolist(), "diagonal_lengths_mm": [float(np.linalg.norm(transformed_marker[2] - transformed_marker[0]) / pixels_per_mm), float(np.linalg.norm(transformed_marker[3] - transformed_marker[1]) / pixels_per_mm)], "homography_reprojection_error_mm": reprojection, "homography_fitting_residual_percent": fitting_residual_percent}
    if validation_points:
        validation_residual_percent, validation_rmse_mm = _validation_residual(matrix, validation_points, pixels_per_mm, marker_width_mm, marker_height_mm)
        diagnostics["validation_rmse_mm"] = validation_rmse_mm
        calibration_validation_status = "independently_validated"
    else:
        validation_residual_percent = None
        calibration_validation_status = "fitted_only"
    scale = ImageScale(1.0 / pixels_per_mm, 1.0 / pixels_per_mm, validation_residual_percent, "planar_marker", calibration_validation_status, diagnostics)
    return HomographyResult(matrix, translation, total, scale, (output_width, output_height), (float(minimum[0]), float(minimum[1]), float(maximum[0]), float(maximum[1])), fitting_residual_percent, reprojection, calibration_validation_status)


def warp_image_and_mask(image: np.ndarray, mask: np.ndarray, result: HomographyResult, probability_mask: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray] | tuple[np.ndarray, np.ndarray, np.ndarray]:
    width, height = result.output_size
    warped_image = cv2.warpPerspective(image, result.total_matrix, (width, height), flags=cv2.INTER_LINEAR)
    warped_mask = cv2.warpPerspective(mask, result.total_matrix, (width, height), flags=cv2.INTER_NEAREST)
    if probability_mask is None:
        return warped_image, warped_mask
    probability = cv2.warpPerspective(probability_mask.astype(np.float32), result.total_matrix, (width, height), flags=cv2.INTER_LINEAR)
    return warped_image, warped_mask, probability


def contour_physical_area(contour: np.ndarray, result: HomographyResult) -> float:
    points = np.asarray(contour, dtype=np.float32).reshape(-1, 2)
    if points.shape[0] < 3:
        raise ValueError("contour requires at least three points")
    transformed = _transform(points, result.matrix) / result.scale.x_mm_per_pixel**-1
    x, y = transformed[:, 0], transformed[:, 1]
    return float(0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))
