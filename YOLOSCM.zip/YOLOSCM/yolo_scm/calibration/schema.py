from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal


@dataclass
class CameraCalibration:
    camera_matrix: list[list[float]]
    distortion_coefficients: list[float]
    image_size: tuple[int, int]
    reprojection_error: float
    checkerboard_size: tuple[int, int]
    square_size_mm: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RulerMetadata:
    mode: Literal["ruler"]
    points: list[list[float]]
    reference_length_mm: float
    surface_angle_deg: float
    environment: Literal["laboratory", "field"]
    allow_provisional_calibration: bool = False


@dataclass
class PlanarMarkerMetadata:
    mode: Literal["planar_marker"]
    corners: list[list[float]]
    marker_width_mm: float
    marker_height_mm: float
    surface_angle_deg: float
    environment: Literal["laboratory", "field"]
    allow_provisional_calibration: bool = False
