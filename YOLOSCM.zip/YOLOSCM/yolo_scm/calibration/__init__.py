from yolo_scm.calibration.scale import ImageScale

__all__ = ["ImageScale"]
