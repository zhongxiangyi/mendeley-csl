from yolo_scm.model.network import YoloScm

__all__ = ["YoloScm"]
