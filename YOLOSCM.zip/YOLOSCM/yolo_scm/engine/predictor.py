from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from torch import Tensor

from yolo_scm.model.network import ModelOutput, YoloScm


@dataclass
class LetterboxTransform:
    original_size: tuple[int, int]
    resized_size: tuple[int, int]
    padding: tuple[int, int, int, int]
    scale: float


@dataclass
class InstancePrediction:
    class_id: int
    confidence: float
    bbox_xyxy: list[float]
    probability_mask: np.ndarray


@dataclass
class DetectionSelection:
    indices: Tensor
    scores: Tensor
    class_ids: Tensor


def letterbox_image(image_rgb: np.ndarray, size: int = 640) -> tuple[np.ndarray, LetterboxTransform]:
    if image_rgb.ndim != 3 or image_rgb.shape[2] != 3:
        raise ValueError("image must be RGB")
    height, width = image_rgb.shape[:2]
    scale = min(size / height, size / width)
    resized_width, resized_height = int(round(width * scale)), int(round(height * scale))
    resized = cv2.resize(image_rgb, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
    left = (size - resized_width) // 2
    top = (size - resized_height) // 2
    right = size - resized_width - left
    bottom = size - resized_height - top
    padded = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return padded, LetterboxTransform((height, width), (resized_height, resized_width), (left, top, right, bottom), scale)


def restore_letterbox_probability(mask: np.ndarray, transform: LetterboxTransform) -> np.ndarray:
    if mask.shape != (640, 640):
        raise ValueError("model probability mask must have shape 640x640")
    left, top, right, bottom = transform.padding
    cropped = mask[top : 640 - bottom, left : 640 - right]
    height, width = transform.original_size
    return cv2.resize(cropped.astype(np.float32), (width, height), interpolation=cv2.INTER_LINEAR)


def _iou(first: np.ndarray, second: np.ndarray) -> float:
    top_left = np.maximum(first[:2], second[:2])
    bottom_right = np.minimum(first[2:], second[2:])
    intersection = np.prod(np.maximum(0.0, bottom_right - top_left))
    area_first = np.prod(np.maximum(0.0, first[2:] - first[:2]))
    area_second = np.prod(np.maximum(0.0, second[2:] - second[:2]))
    return float(intersection / (area_first + area_second - intersection + 1e-9))


def _nms(boxes: np.ndarray, scores: np.ndarray, classes: np.ndarray, threshold: float) -> list[int]:
    selected: list[int] = []
    for class_id in np.unique(classes):
        order = np.where(classes == class_id)[0]
        order = order[np.argsort(scores[order])[::-1]]
        while order.size:
            current = int(order[0])
            selected.append(current)
            order = np.asarray([index for index in order[1:] if _iou(boxes[current], boxes[int(index)]) <= threshold], dtype=np.int64)
    return selected


def classwise_nms_indices(boxes: np.ndarray, scores: np.ndarray, classes: np.ndarray, threshold: float, max_detections: int = 300) -> np.ndarray:
    if boxes.ndim != 2 or boxes.shape[1] != 4 or scores.ndim != 1 or classes.ndim != 1 or boxes.shape[0] != scores.shape[0] or boxes.shape[0] != classes.shape[0]:
        raise ValueError("boxes, scores and classes must have matching detection dimensions")
    if not 0.0 <= threshold <= 1.0 or max_detections <= 0:
        raise ValueError("threshold must be in [0, 1] and max_detections must be positive")
    selected = _nms(boxes, scores, classes, threshold)
    ordered = sorted(selected, key=lambda index: float(scores[index]), reverse=True)[:max_detections]
    return np.asarray(ordered, dtype=np.int64)


def select_classwise_detections(boxes: Tensor, class_logits: Tensor, confidence_threshold: float, nms_iou_threshold: float, max_detections: int = 300) -> DetectionSelection:
    if boxes.ndim != 2 or boxes.shape[1] != 4 or class_logits.ndim != 2 or boxes.shape[0] != class_logits.shape[0]:
        raise ValueError("boxes and class_logits must have matching detection dimensions")
    if not 0.0 <= confidence_threshold <= 1.0:
        raise ValueError("confidence_threshold must be between zero and one")
    probabilities = torch.sigmoid(class_logits)
    scores, class_ids = probabilities.max(dim=1)
    candidates = torch.nonzero(scores >= confidence_threshold, as_tuple=False).flatten()
    if candidates.numel() == 0:
        empty_indices = torch.empty(0, dtype=torch.long, device=boxes.device)
        empty_scores = torch.empty(0, dtype=scores.dtype, device=boxes.device)
        empty_classes = torch.empty(0, dtype=class_ids.dtype, device=boxes.device)
        return DetectionSelection(empty_indices, empty_scores, empty_classes)
    relative = classwise_nms_indices(boxes[candidates].detach().cpu().numpy(), scores[candidates].detach().cpu().numpy(), class_ids[candidates].detach().cpu().numpy(), nms_iou_threshold, max_detections)
    selected = candidates[torch.as_tensor(relative, dtype=torch.long, device=boxes.device)]
    return DetectionSelection(selected, scores[selected], class_ids[selected])


class Predictor:
    def __init__(self, model: YoloScm, device: torch.device, confidence_threshold: float = 0.25, nms_iou_threshold: float = 0.7, max_detections: int = 300) -> None:
        if not 0.0 <= confidence_threshold <= 1.0 or not 0.0 <= nms_iou_threshold <= 1.0 or max_detections <= 0:
            raise ValueError("confidence_threshold and nms_iou_threshold must be between zero and one and max_detections must be positive")
        self.model = model.to(device).eval()
        self.device = device
        self.confidence_threshold = confidence_threshold
        self.nms_iou_threshold = nms_iou_threshold
        self.max_detections = max_detections

    @classmethod
    def from_checkpoint(cls, model: YoloScm, checkpoint_path: Path, device: torch.device, confidence_threshold: float = 0.25, nms_iou_threshold: float = 0.7, max_detections: int = 300) -> Predictor:
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        if not isinstance(checkpoint, dict) or "model" not in checkpoint or "metadata" not in checkpoint:
            raise ValueError("checkpoint does not contain model and metadata")
        model.load_compatible_state_dict(checkpoint["model"], checkpoint["metadata"])
        return cls(model, device, confidence_threshold, nms_iou_threshold, max_detections)

    def output_rgb(self, image_rgb: np.ndarray) -> tuple[ModelOutput, LetterboxTransform]:
        image, transform = letterbox_image(image_rgb)
        tensor = torch.from_numpy(np.ascontiguousarray(image.transpose(2, 0, 1))).float().div(255.0).unsqueeze(0).to(self.device)
        with torch.inference_mode():
            return self.model(tensor), transform

    def predict_rgb(self, image_rgb: np.ndarray) -> list[InstancePrediction]:
        output, transform = self.output_rgb(image_rgb)
        selection = select_classwise_detections(output.boxes[0], output.class_logits[0], self.confidence_threshold, self.nms_iou_threshold, self.max_detections)
        if selection.indices.numel() == 0:
            return []
        boxes = output.boxes[0, selection.indices].detach().cpu().numpy()
        coefficients = output.mask_coefficients[0, selection.indices]
        masks = self.model.decode_instance_masks(coefficients.unsqueeze(0), output.prototypes, output.boxes[0, selection.indices].unsqueeze(0))[0].detach().cpu().numpy()
        left, top, _, _ = transform.padding
        scale = transform.scale
        result: list[InstancePrediction] = []
        for local_index in range(selection.indices.numel()):
            probability = restore_letterbox_probability(masks[local_index], transform)
            box = boxes[local_index].copy()
            box[[0, 2]] = (box[[0, 2]] - left) / scale
            box[[1, 3]] = (box[[1, 3]] - top) / scale
            height, width = transform.original_size
            box[[0, 2]] = np.clip(box[[0, 2]], 0, width)
            box[[1, 3]] = np.clip(box[[1, 3]], 0, height)
            result.append(InstancePrediction(int(selection.class_ids[local_index]), float(selection.scores[local_index]), box.astype(float).tolist(), probability))
        return result

    def predict_path(self, image_path: Path) -> tuple[np.ndarray, list[InstancePrediction]]:
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f"unable to read image {image_path}")
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        return rgb, self.predict_rgb(rgb)
