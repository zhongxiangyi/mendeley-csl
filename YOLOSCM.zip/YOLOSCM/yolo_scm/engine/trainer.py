from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from typing import Any

import torch
import yaml
from torch import nn
from torch.optim import Optimizer
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from yolo_scm.data.collate import collate_instances
from yolo_scm.data.dataset import YoloInstanceDataset
from yolo_scm.engine.evaluator import EvaluatedInstance, evaluate_instances, summarize_runs
from yolo_scm.engine.predictor import select_classwise_detections
from yolo_scm.engine.reproducibility import set_deterministic_seed
from yolo_scm.model.losses import YoloScmLoss
from yolo_scm.model.network import YoloScm


def _load(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict):
        raise ValueError("configuration must be mapping")
    return value


def _optimizer(model: nn.Module, defaults: dict[str, Any], weight_decay: float) -> Optimizer:
    name = str(defaults["optimizer"])
    learning_rate = float(defaults["learning_rate"])
    momentum = float(defaults["momentum"])
    if name != "SGD":
        raise ValueError("only configured SGD optimizer is supported")
    return torch.optim.SGD(model.parameters(), lr=learning_rate, momentum=momentum, weight_decay=weight_decay, nesterov=True)


def update_best_state(best_loss: float, best_epoch: int, best_evaluation: dict[str, float], validation_loss: float, epoch: int, evaluation: dict[str, float]) -> tuple[float, int, dict[str, float], bool]:
    if validation_loss < best_loss:
        return validation_loss, epoch, dict(evaluation), True
    return best_loss, best_epoch, best_evaluation, False


def _validation_instances(model: YoloScm, boxes: torch.Tensor, class_logits: torch.Tensor, mask_coefficients: torch.Tensor, prototypes: torch.Tensor, image_id: str, confidence_threshold: float, nms_iou_threshold: float, max_detections: int) -> list[EvaluatedInstance]:
    selection = select_classwise_detections(boxes, class_logits, confidence_threshold, nms_iou_threshold, max_detections)
    if selection.indices.numel() == 0:
        return []
    masks = model.decode_instance_masks(mask_coefficients[selection.indices].unsqueeze(0), prototypes.unsqueeze(0), boxes[selection.indices].unsqueeze(0))[0].cpu().numpy()
    selected_boxes = boxes[selection.indices].detach().cpu().numpy()
    return [EvaluatedInstance(image_id, int(selection.class_ids[index].item()), float(selection.scores[index].item()), masks[index] >= 0.5, selected_boxes[index]) for index in range(selection.indices.numel())]


def train_seed(model: YoloScm, data_config: Path, paper_config: Path, defaults_config: Path, output_root: Path, seed: int, resume: Path | None = None, max_epochs_override: int | None = None) -> dict[str, Any]:
    started = time.perf_counter()
    set_deterministic_seed(seed)
    paper = _load(paper_config)
    defaults = _load(defaults_config)["implementation_defaults"]
    train_config = paper["training"]
    run_directory = output_root / f"seed_{seed}"
    run_directory.mkdir(parents=True, exist_ok=True)
    with (run_directory / "config_snapshot.yaml").open("w", encoding="utf-8") as handle:
        yaml.safe_dump({"paper": paper, "implementation_defaults": defaults}, handle, sort_keys=False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train_dataset = YoloInstanceDataset(data_config, "train", paper_config, train=True, defaults_config=defaults_config)
    val_dataset = YoloInstanceDataset(data_config, "val", paper_config, train=False, defaults_config=defaults_config)
    workers = int(defaults["workers"])
    loader = DataLoader(train_dataset, batch_size=int(train_config["batch_size"]), shuffle=True, num_workers=workers, pin_memory=device.type == "cuda", collate_fn=collate_instances)
    validation_loader = DataLoader(val_dataset, batch_size=int(train_config["batch_size"]), shuffle=False, num_workers=workers, pin_memory=device.type == "cuda", collate_fn=collate_instances)
    model = model.to(device)
    optimizer = _optimizer(model, defaults, float(train_config["weight_decay"]))
    epochs = int(max_epochs_override if max_epochs_override is not None else train_config["max_epochs"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, epochs - int(train_config["warmup_epochs"])))
    loss_function = YoloScmLoss(train_config["loss_weights"], model.num_classes, model.reg_max).to(device)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    accumulation = int(defaults["gradient_accumulation"])
    if accumulation <= 0:
        raise ValueError("gradient_accumulation must be positive")
    start_epoch = 0
    best_loss = float("inf")
    best_epoch = -1
    best_evaluation: dict[str, float] = {}
    if resume is not None:
        checkpoint = torch.load(resume, map_location=device, weights_only=False)
        model.load_compatible_state_dict(checkpoint["model"], checkpoint["metadata"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_epoch = int(checkpoint["epoch"]) + 1
        best_loss = float(checkpoint["best_loss"])
        best_epoch = int(checkpoint["best_epoch"])
        stored_evaluation = checkpoint["best_evaluation"]
        if not isinstance(stored_evaluation, dict):
            raise ValueError("checkpoint best_evaluation is invalid")
        best_evaluation = {str(key): float(value) for key, value in stored_evaluation.items()}
    writer = SummaryWriter(str(run_directory / "tensorboard"))
    metrics_path = run_directory / "metrics.csv"
    with metrics_path.open("w", encoding="utf-8", newline="") as handle:
        fields = ["epoch", "train_total_loss", "train_box_loss", "train_cls_loss", "train_dfl_loss", "train_mask_loss", "train_dice_loss", "train_boundary_loss", "val_total_loss", "precision_crack", "precision_spalling", "recall_crack", "recall_spalling", "F1_crack", "F1_spalling", "macro_F1", "mask_AP50_crack", "mask_AP50_spalling", "mask_mAP50", "mask_mAP50_95", "IoU_crack", "IoU_spalling", "mean_IoU"]
        metric_writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        metric_writer.writeheader()
        patience = 0
        final_epoch = -1
        evaluation: dict[str, float] = {}
        validation_confidence_threshold = float(defaults["validation_confidence_threshold"])
        nms_iou_threshold = float(defaults["nms_iou_threshold"])
        max_detections = int(defaults["max_detections"])
        for epoch in range(start_epoch, epochs):
            final_epoch = epoch
            warmup_epochs = int(train_config["warmup_epochs"])
            if epoch < warmup_epochs:
                warmup_factor = float(epoch + 1) / float(max(1, warmup_epochs))
                for group in optimizer.param_groups:
                    group["lr"] = float(defaults["learning_rate"]) * warmup_factor
            model.train()
            train_values = {"total": 0.0, "box": 0.0, "cls": 0.0, "dfl": 0.0, "mask": 0.0, "dice": 0.0, "boundary": 0.0}
            optimizer.zero_grad(set_to_none=True)
            for batch_index, batch in enumerate(loader):
                images = batch["images"].to(device)
                with torch.autocast(device_type=device.type, enabled=device.type == "cuda"):
                    result = loss_function(model(images), batch["targets"])
                scaler.scale(result.total / accumulation).backward()
                if (batch_index + 1) % accumulation == 0 or batch_index + 1 == len(loader):
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                for key in train_values:
                    train_values[key] += float(getattr(result, key).detach().cpu())
            model.eval()
            validation_values = {"total": 0.0, "box": 0.0, "cls": 0.0, "dfl": 0.0, "mask": 0.0, "dice": 0.0, "boundary": 0.0}
            predicted_instances: list[EvaluatedInstance] = []
            target_instances: list[EvaluatedInstance] = []
            with torch.inference_mode():
                for validation_index, batch in enumerate(validation_loader):
                    images = batch["images"].to(device)
                    output = model(images)
                    validation = loss_function(output, batch["targets"])
                    for key in validation_values:
                        validation_values[key] += float(getattr(validation, key).detach().cpu())
                    for batch_index, target in enumerate(batch["targets"]):
                        image_id = f"{validation_index}_{batch_index}"
                        predicted_instances.extend(_validation_instances(model, output.boxes[batch_index], output.class_logits[batch_index], output.mask_coefficients[batch_index], output.prototypes[batch_index], image_id, validation_confidence_threshold, nms_iou_threshold, max_detections))
                        for instance_index in range(target["labels"].shape[0]):
                            target_instances.append(EvaluatedInstance(image_id, int(target["labels"][instance_index]), 1.0, target["masks"][instance_index].numpy().astype(bool), target["boxes"][instance_index].numpy()))
            train_average = {key: value / max(1, len(loader)) for key, value in train_values.items()}
            validation_average = {key: value / max(1, len(validation_loader)) for key, value in validation_values.items()}
            if not torch.isfinite(torch.tensor(validation_average["total"])):
                raise FloatingPointError("validation loss is not finite")
            evaluation = evaluate_instances(predicted_instances, target_instances)
            row = {"epoch": epoch, "train_total_loss": train_average["total"], "train_box_loss": train_average["box"], "train_cls_loss": train_average["cls"], "train_dfl_loss": train_average["dfl"], "train_mask_loss": train_average["mask"], "train_dice_loss": train_average["dice"], "train_boundary_loss": train_average["boundary"], "val_total_loss": validation_average["total"], **evaluation}
            metric_writer.writerow(row)
            handle.flush()
            writer.add_scalar("loss/train", train_average["total"], epoch)
            writer.add_scalar("loss/validation", validation_average["total"], epoch)
            best_loss, best_epoch, best_evaluation, improved = update_best_state(best_loss, best_epoch, best_evaluation, validation_average["total"], epoch, evaluation)
            checkpoint = {"model": model.state_dict(), "metadata": model.compatibility(), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(), "epoch": epoch, "best_loss": best_loss, "best_epoch": best_epoch, "best_evaluation": best_evaluation}
            torch.save(checkpoint, run_directory / "last.pt")
            if improved:
                torch.save(checkpoint, run_directory / "best.pt")
                patience = 0
            else:
                patience += 1
            if epoch >= warmup_epochs:
                scheduler.step()
            if patience >= int(train_config["early_stopping_patience"]):
                break
    writer.close()
    if best_epoch < 0:
        raise RuntimeError("training completed without a validation epoch")
    result: dict[str, Any] = {"seed": float(seed), "best_validation_loss": best_loss, "best_epoch": float(best_epoch), "best_evaluation": best_evaluation, "final_epoch": float(final_epoch), "training_time": float(time.perf_counter() - started), **best_evaluation}
    (run_directory / "metrics.json").write_text(json.dumps(result, indent=2, allow_nan=True), encoding="utf-8")
    from yolo_scm.cli.profile_model import profile_model
    parameters, gflops = profile_model(model.cpu(), model.input_size)
    (run_directory / "model_profile.json").write_text(json.dumps({"parameters": parameters, "gflops": gflops, "fp16_model_size_mb": parameters * 2 / 1_000_000.0}, indent=2), encoding="utf-8")
    return result


def train_many(model_factory: Any, data_config: Path, paper_config: Path, defaults_config: Path, output_root: Path, seeds: list[int] | None = None) -> dict[str, Any]:
    paper = _load(paper_config)
    run_seeds = seeds if seeds is not None else [int(value) for value in paper["training"]["seeds"]]
    results = [train_seed(model_factory(), data_config, paper_config, defaults_config, output_root, seed) for seed in run_seeds]
    summary_metrics = [{**result["best_evaluation"], "best_epoch": float(result["best_epoch"]), "training_time": float(result["training_time"])} for result in results]
    summary = {"runs": results, "metrics": summarize_runs(summary_metrics)}
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=True), encoding="utf-8")
    with (output_root / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["metric", "mean", "standard_deviation", "minimum", "maximum", "number_of_runs"])
        writer.writeheader()
        for metric, values in summary["metrics"].items():
            writer.writerow({"metric": metric, **values})
    return summary
