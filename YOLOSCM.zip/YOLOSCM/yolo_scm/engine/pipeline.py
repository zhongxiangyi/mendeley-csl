from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch

from yolo_scm.calibration.camera import load_camera_calibration, undistort
from yolo_scm.calibration.homography import marker_homography, warp_image_and_mask
from yolo_scm.calibration.scale import ImageScale, scale_from_metadata
from yolo_scm.engine.predictor import InstancePrediction, Predictor, letterbox_image, restore_letterbox_probability
from yolo_scm.calibration.validation import CalibrationDecision, validate_measurement
from yolo_scm.model.parser import build_model
from yolo_scm.quantification.crack import quantify_crack
from yolo_scm.quantification.export import export_measurements
from yolo_scm.quantification.refinement import display_mask, refine_instance_mask
from yolo_scm.quantification.spalling import quantify_spalling
from yolo_scm.quantification.visualization import save_crack_visuals, save_overlay, save_spalling_visuals


def _metadata(path: Path | None) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if isinstance(value, list):
        return {str(item["image_id"]): item for item in value}
    if isinstance(value, dict) and isinstance(value.get("images"), dict):
        return {str(key): item for key, item in value["images"].items()}
    if isinstance(value, dict):
        return {str(key): item for key, item in value.items()}
    raise ValueError("measurement metadata must be an object or list")


def _scale(metadata: dict[str, Any], image: np.ndarray, mask: np.ndarray) -> tuple[ImageScale | None, np.ndarray, np.ndarray]:
    mode = metadata.get("mode")
    if mode == "ruler":
        return scale_from_metadata(metadata), image, mask
    if mode == "planar_marker":
        damage = np.column_stack(np.nonzero(mask))[:, ::-1] if int(mask.sum()) else None
        validation_points = metadata.get("validation_points")
        if validation_points is not None and not isinstance(validation_points, list):
            raise ValueError("validation_points must be a list")
        homography = marker_homography(metadata["corners"], image.shape[:2], damage, float(metadata.get("marker_width_mm", 25.0)), float(metadata.get("marker_height_mm", 30.0)), 20.0, validation_points)
        warped_image, warped_mask = warp_image_and_mask(image, mask, homography)
        return homography.scale, warped_image, warped_mask
    return None, image, mask


def _record(image_id: str, instance_id: int, prediction: InstancePrediction, mask: np.ndarray, scale: ImageScale | None, decision: CalibrationDecision, metadata: dict[str, Any], crack: dict[str, Any] | None, spalling: dict[str, Any] | None) -> dict[str, Any]:
    record: dict[str, Any] = {"image_id": image_id, "instance_id": instance_id, "class_id": prediction.class_id, "class_name": "crack" if prediction.class_id == 0 else "spalling", "confidence": prediction.confidence, "bbox_xyxy": prediction.bbox_xyxy, "mask_pixel_count": int(mask.sum()), "pixel_scale_x_mm": None if scale is None or not decision.reliable else scale.x_mm_per_pixel, "pixel_scale_y_mm": None if scale is None or not decision.reliable else scale.y_mm_per_pixel, "crack_length_pixels": None, "maximum_crack_width_pixels": None, "average_crack_width_pixels": None, "median_crack_width_pixels": None, "spalling_pixel_area": None, "crack_length_mm": None, "maximum_crack_width_mm": None, "average_crack_width_mm": None, "median_crack_width_mm": None, "spalling_area_mm2": None, "spalling_area_cm2": None, "perimeter_mm": None, "reliable": decision.reliable, "reliability_status": decision.status, "rejection_reasons": decision.reasons, "calibration_residual_percent": None if scale is None else scale.residual_percent, "calibration_validation_status": None if scale is None else scale.calibration_validation_status, "homography_fitting_residual_percent": None if scale is None else scale.diagnostics.get("homography_fitting_residual_percent"), "surface_angle_deg": float(metadata.get("surface_angle_deg", 0.0))}
    if crack is not None:
        widths = crack["all_width_statistics"]
        pixel_widths = crack["all_width_statistics_pixels"]
        record.update({"crack_length_pixels": crack["pixel_length"], "maximum_crack_width_pixels": pixel_widths["maximum_width_pixels"], "average_crack_width_pixels": pixel_widths["average_width_pixels"], "median_crack_width_pixels": pixel_widths["median_width_pixels"], "crack_length_mm": crack["crack_length_mm"] if decision.reliable else None, "maximum_crack_width_mm": widths["maximum_width_mm"] if decision.reliable else None, "average_crack_width_mm": widths["average_width_mm"] if decision.reliable else None, "median_crack_width_mm": widths["median_width_mm"] if decision.reliable else None, "reliable": bool(decision.reliable and crack["reliable_flag"])})
    if spalling is not None:
        record.update({"spalling_pixel_area": spalling["pixel_area"], "spalling_area_mm2": spalling["area_mm2"] if decision.reliable else None, "spalling_area_cm2": spalling["area_cm2"] if decision.reliable else None, "perimeter_mm": spalling["perimeter_mm"] if decision.reliable else None})
    return record


def _directories(output: Path) -> dict[str, Path]:
    names = ["originals", "masks", "probability_masks", "overlays", "final_composites", "crack_skeletons", "crack_width_lines", "crack_width_heatmaps", "spalling_contours", "spalling_area_maps", "per_instance"]
    directories = {name: output / name for name in names}
    for directory in directories.values():
        directory.mkdir(parents=True, exist_ok=True)
    return directories


def run_pipeline(weights: Path | None, source: Path | None, output: Path, camera_calibration: Path | None = None, measurement_metadata: Path | None = None, confidence_threshold: float = 0.25, nms_iou_threshold: float = 0.7, smoke_test: bool = False, allow_provisional_calibration: bool = False) -> list[dict[str, Any]]:
    directories = _directories(output)
    if smoke_test:
        image = np.full((720, 960, 3), 160, dtype=np.uint8)
        image[320:500, 520:760] = (180, 130, 100)
        crack_probability = np.zeros(image.shape[:2], dtype=np.float32)
        crack_probability[140:520, 240:246] = 0.99
        spalling_probability = np.zeros(image.shape[:2], dtype=np.float32)
        spalling_probability[320:500, 520:760] = 0.99
        model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml")).eval()
        letterboxed, transform = letterbox_image(image)
        with torch.inference_mode():
            head_output = model(torch.from_numpy(np.ascontiguousarray(letterboxed.transpose(2, 0, 1))).float().div(255.0).unsqueeze(0))
        if head_output.boxes.numel() == 0 or head_output.class_logits.numel() == 0 or head_output.mask_coefficients.numel() == 0 or head_output.prototypes.numel() == 0:
            raise RuntimeError("smoke model output is incomplete")
        decoded = torch.sigmoid(model.decode_masks(head_output.mask_coefficients[:, :1], head_output.prototypes, (640, 640))[0, 0]).detach().cpu().numpy()
        restored_head = restore_letterbox_probability(decoded, transform)
        cv2.imwrite(str(directories["probability_masks"] / "synthetic_head_decoded.png"), np.clip(restored_head * 255.0, 0, 255).astype(np.uint8))
        ruler_metadata = {"mode": "ruler", "segments": [{"points": [[100.0, 80.0], [500.0, 80.0]], "reference_length_mm": 20.0}], "verification_segments": [{"points": [[100.0, 100.0], [500.0, 100.0]], "reference_length_mm": 20.0}], "surface_angle_deg": 0.0, "environment": "laboratory", "calibration_object_complete": True, "approximately_coplanar": True}
        marker_metadata = {"mode": "planar_marker", "corners": [[80.0, 80.0], [580.0, 80.0], [580.0, 680.0], [80.0, 680.0]], "marker_width_mm": 25.0, "marker_height_mm": 30.0, "surface_angle_deg": 0.0, "environment": "laboratory", "calibration_object_complete": True, "approximately_coplanar": True, "allow_provisional_calibration": True}
        records: list[dict[str, Any]] = []
        synthetic = [(InstancePrediction(0, 1.0, [240.0, 140.0, 246.0, 520.0], crack_probability), ruler_metadata), (InstancePrediction(1, 1.0, [520.0, 320.0, 760.0, 500.0], spalling_probability), marker_metadata)]
        composite = image.copy()
        for instance_id, (prediction, metadata) in enumerate(synthetic):
            mask = refine_instance_mask(prediction.probability_mask, image, prediction.class_id)
            scale, _, measurement_mask = _scale(metadata, image, mask)
            decision = validate_measurement(metadata, scale)
            stem = f"synthetic_{instance_id:04d}"
            cv2.imwrite(str(directories["masks"] / f"{stem}.png"), mask * 255)
            cv2.imwrite(str(directories["probability_masks"] / f"{stem}.png"), np.clip(prediction.probability_mask * 255.0, 0, 255).astype(np.uint8))
            save_overlay(image, display_mask(mask), directories["overlays"] / f"{stem}.png", (255, 0, 0) if prediction.class_id == 0 else (0, 255, 0))
            crack_result = quantify_crack(measurement_mask, scale if decision.reliable else None, "laboratory") if prediction.class_id == 0 else None
            spalling_result = quantify_spalling(measurement_mask, scale if decision.reliable else None) if prediction.class_id == 1 else None
            if crack_result is not None:
                save_crack_visuals(measurement_mask, crack_result["skeleton"], crack_result["width_lines"], directories["crack_skeletons"] / f"{stem}.png", directories["crack_width_lines"] / f"{stem}.png", directories["crack_width_heatmaps"] / f"{stem}.png")
            if spalling_result is not None:
                save_spalling_visuals(measurement_mask, directories["spalling_contours"] / f"{stem}.png", directories["spalling_area_maps"] / f"{stem}.png")
            record = _record("synthetic_smoke_test", instance_id, prediction, mask, scale, decision, metadata, crack_result, spalling_result)
            record["synthetic_smoke_test"] = True
            records.append(record)
            composite[display_mask(mask).astype(bool)] = (255, 0, 0) if prediction.class_id == 0 else (0, 255, 0)
        cv2.imwrite(str(directories["originals"] / "synthetic.png"), cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
        cv2.imwrite(str(directories["final_composites"] / "synthetic.png"), cv2.cvtColor(composite, cv2.COLOR_RGB2BGR))
        export_measurements(records, output)
        return records
    if weights is None or source is None:
        raise ValueError("weights and source are required unless smoke_test is enabled")
    if not weights.exists() or not source.exists():
        raise FileNotFoundError("weights or source path does not exist")
    model = build_model(Path("configs/paper.yaml"), Path("configs/implementation_defaults.yaml"))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    predictor = Predictor.from_checkpoint(model, weights, device, confidence_threshold, nms_iou_threshold)
    calibration = load_camera_calibration(camera_calibration) if camera_calibration is not None else None
    metadata_by_image = _metadata(measurement_metadata)
    image_paths = [source] if source.is_file() else sorted(path for path in source.rglob("*") if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"})
    if not image_paths:
        raise ValueError("source contains no images")
    records: list[dict[str, Any]] = []
    for image_path in image_paths:
        image, predictions = predictor.predict_path(image_path)
        if calibration is not None:
            image = undistort(image, calibration)
            predictions = predictor.predict_rgb(image)
        image_id = image_path.stem
        metadata = dict(metadata_by_image.get(image_id, {}))
        if allow_provisional_calibration:
            metadata["allow_provisional_calibration"] = True
        cv2.imwrite(str(directories["originals"] / f"{image_id}.png"), cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
        composite = image.copy()
        for instance_id, prediction in enumerate(predictions):
            mask = refine_instance_mask(prediction.probability_mask, image, prediction.class_id)
            scale, _, measurement_mask = _scale(metadata, image, mask)
            decision = validate_measurement(metadata, scale)
            stem = f"{image_id}_{instance_id:04d}"
            cv2.imwrite(str(directories["masks"] / f"{stem}.png"), mask * 255)
            cv2.imwrite(str(directories["probability_masks"] / f"{stem}.png"), np.clip(prediction.probability_mask * 255.0, 0, 255).astype(np.uint8))
            save_overlay(image, display_mask(mask), directories["overlays"] / f"{stem}.png", (255, 0, 0) if prediction.class_id == 0 else (0, 255, 0))
            composite[display_mask(mask).astype(bool)] = (255, 0, 0) if prediction.class_id == 0 else (0, 255, 0)
            crack_result: dict[str, Any] | None = None
            spalling_result: dict[str, Any] | None = None
            if prediction.class_id == 0:
                crack_result = quantify_crack(measurement_mask, scale if decision.reliable else None, str(metadata.get("environment", "laboratory")))
                save_crack_visuals(measurement_mask, crack_result["skeleton"], crack_result["width_lines"], directories["crack_skeletons"] / f"{stem}.png", directories["crack_width_lines"] / f"{stem}.png", directories["crack_width_heatmaps"] / f"{stem}.png")
            else:
                spalling_result = quantify_spalling(measurement_mask, scale if decision.reliable else None)
                save_spalling_visuals(measurement_mask, directories["spalling_contours"] / f"{stem}.png", directories["spalling_area_maps"] / f"{stem}.png")
            record = _record(image_id, instance_id, prediction, mask, scale, decision, metadata, crack_result, spalling_result)
            records.append(record)
            (directories["per_instance"] / f"{stem}.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        cv2.imwrite(str(directories["final_composites"] / f"{image_id}.png"), cv2.cvtColor(composite, cv2.COLOR_RGB2BGR))
    export_measurements(records, output)
    return records
