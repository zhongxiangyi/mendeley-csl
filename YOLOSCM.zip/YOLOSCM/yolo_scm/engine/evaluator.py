from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np

from yolo_scm.quantification.agreement import agreement_statistics


@dataclass
class EvaluatedInstance:
    image_id: str
    class_id: int
    confidence: float
    mask: np.ndarray
    box: np.ndarray


def _mask_iou(first: np.ndarray, second: np.ndarray) -> float:
    if first.shape != second.shape:
        raise ValueError("instance masks must share a coordinate system and shape")
    intersection = np.logical_and(first.astype(bool), second.astype(bool)).sum()
    union = np.logical_or(first.astype(bool), second.astype(bool)).sum()
    return float(intersection / union) if union else 0.0


def _box_iou(first: np.ndarray, second: np.ndarray) -> float:
    top_left = np.maximum(first[:2], second[:2])
    bottom_right = np.minimum(first[2:], second[2:])
    intersection = np.prod(np.maximum(bottom_right - top_left, 0.0))
    first_area = np.prod(np.maximum(first[2:] - first[:2], 0.0))
    second_area = np.prod(np.maximum(second[2:] - second[:2], 0.0))
    denominator = first_area + second_area - intersection
    return float(intersection / denominator) if denominator > 0 else 0.0


def _integrated_ap(recall: np.ndarray, precision: np.ndarray) -> float:
    envelope = np.maximum.accumulate(precision[::-1])[::-1]
    values = [float(envelope[np.where(recall >= point)[0][0]]) if np.any(recall >= point) else 0.0 for point in np.linspace(0.0, 1.0, 101)]
    return float(np.mean(values))


def _class_matches(predictions: Sequence[EvaluatedInstance], targets: Sequence[EvaluatedInstance], class_id: int, threshold: float, mask_mode: bool) -> tuple[np.ndarray, np.ndarray, int]:
    relevant_predictions = sorted((item for item in predictions if item.class_id == class_id), key=lambda item: item.confidence, reverse=True)
    relevant_targets = [item for item in targets if item.class_id == class_id]
    assigned: set[tuple[str, int]] = set()
    true_positive: list[float] = []
    false_positive: list[float] = []
    for prediction in relevant_predictions:
        candidates = [(index, target) for index, target in enumerate(relevant_targets) if target.image_id == prediction.image_id and (target.image_id, index) not in assigned]
        if not candidates:
            true_positive.append(0.0)
            false_positive.append(1.0)
            continue
        scores = [_mask_iou(prediction.mask, target.mask) if mask_mode else _box_iou(prediction.box, target.box) for _, target in candidates]
        best = int(np.argmax(scores))
        target_index, _ = candidates[best]
        if scores[best] >= threshold:
            assigned.add((prediction.image_id, target_index))
            true_positive.append(1.0)
            false_positive.append(0.0)
        else:
            true_positive.append(0.0)
            false_positive.append(1.0)
    return np.asarray(true_positive), np.asarray(false_positive), len(relevant_targets)


def _ap(predictions: Sequence[EvaluatedInstance], targets: Sequence[EvaluatedInstance], class_id: int, threshold: float, mask_mode: bool) -> tuple[float, float, float, float, float]:
    true_positive, false_positive, target_count = _class_matches(predictions, targets, class_id, threshold, mask_mode)
    if target_count == 0:
        return float("nan"), float("nan"), float("nan"), float("nan"), float("nan")
    if true_positive.size == 0:
        return 0.0, 0.0, 0.0, 0.0, float("nan")
    cumulative_tp = np.cumsum(true_positive)
    cumulative_fp = np.cumsum(false_positive)
    recall = cumulative_tp / target_count
    precision = cumulative_tp / np.maximum(cumulative_tp + cumulative_fp, 1e-12)
    ap = _integrated_ap(recall, precision)
    f1 = 2.0 * precision * recall / np.maximum(precision + recall, 1e-12)
    best_index = int(np.argmax(f1))
    confidences = [item.confidence for item in sorted((item for item in predictions if item.class_id == class_id), key=lambda item: item.confidence, reverse=True)]
    return ap, float(precision[best_index]), float(recall[best_index]), float(f1[best_index]), float(confidences[best_index])


def _class_iou(predictions: Sequence[EvaluatedInstance], targets: Sequence[EvaluatedInstance], class_id: int) -> float:
    image_ids = sorted({item.image_id for item in predictions}.union(item.image_id for item in targets))
    intersection = 0
    union = 0
    for image_id in image_ids:
        predicted = [item.mask for item in predictions if item.image_id == image_id and item.class_id == class_id]
        expected = [item.mask for item in targets if item.image_id == image_id and item.class_id == class_id]
        shapes = {item.shape for item in [*predicted, *expected]}
        if not shapes:
            continue
        if len(shapes) != 1:
            raise ValueError("class masks have mismatched evaluation shapes")
        shape = next(iter(shapes))
        prediction = np.logical_or.reduce(predicted) if predicted else np.zeros(shape, dtype=bool)
        target = np.logical_or.reduce(expected) if expected else np.zeros(shape, dtype=bool)
        intersection += int(np.logical_and(prediction, target).sum())
        union += int(np.logical_or(prediction, target).sum())
    return float(intersection / union) if union else float("nan")


def evaluate_instances(predictions: Sequence[EvaluatedInstance], targets: Sequence[EvaluatedInstance], num_classes: int = 2) -> dict[str, float]:
    if num_classes != 2:
        raise ValueError("YOLO-SCM evaluation requires two classes")
    metrics: dict[str, float] = {}
    mask_ap50: list[float] = []
    mask_ap5095: list[float] = []
    bbox_ap50: list[float] = []
    bbox_ap5095: list[float] = []
    f1_values: list[float] = []
    iou_values: list[float] = []
    for class_id, name in enumerate(("crack", "spalling")):
        ap50, precision, recall, f1, best_confidence = _ap(predictions, targets, class_id, 0.5, True)
        mask_thresholds = [_ap(predictions, targets, class_id, threshold, True)[0] for threshold in np.arange(0.5, 1.0, 0.05)]
        bbox50 = _ap(predictions, targets, class_id, 0.5, False)[0]
        bbox_thresholds = [_ap(predictions, targets, class_id, threshold, False)[0] for threshold in np.arange(0.5, 1.0, 0.05)]
        iou = _class_iou(predictions, targets, class_id)
        metrics[f"mask_AP50_{name}"] = ap50
        metrics[f"mask_mAP50_95_{name}"] = float(np.nanmean(mask_thresholds)) if not np.all(np.isnan(mask_thresholds)) else float("nan")
        metrics[f"bbox_AP50_{name}"] = bbox50
        metrics[f"bbox_mAP50_95_{name}"] = float(np.nanmean(bbox_thresholds)) if not np.all(np.isnan(bbox_thresholds)) else float("nan")
        metrics[f"precision_{name}"] = precision
        metrics[f"recall_{name}"] = recall
        metrics[f"F1_{name}"] = f1
        metrics[f"best_F1_confidence_{name}"] = best_confidence
        metrics[f"IoU_{name}"] = iou
        if not np.isnan(ap50):
            mask_ap50.append(ap50)
            mask_ap5095.append(metrics[f"mask_mAP50_95_{name}"])
            bbox_ap50.append(bbox50)
            bbox_ap5095.append(metrics[f"bbox_mAP50_95_{name}"])
            f1_values.append(f1)
        if not np.isnan(iou):
            iou_values.append(iou)
    metrics["mask_mAP50"] = float(np.mean(mask_ap50)) if mask_ap50 else float("nan")
    metrics["mask_mAP50_95"] = float(np.mean(mask_ap5095)) if mask_ap5095 else float("nan")
    metrics["bbox_mAP50"] = float(np.mean(bbox_ap50)) if bbox_ap50 else float("nan")
    metrics["bbox_mAP50_95"] = float(np.mean(bbox_ap5095)) if bbox_ap5095 else float("nan")
    metrics["macro_F1"] = float(np.mean(f1_values)) if f1_values else float("nan")
    metrics["mean_IoU"] = float(np.mean(iou_values)) if iou_values else float("nan")
    return metrics


def summarize_runs(metrics: list[dict[str, float]]) -> dict[str, dict[str, float]]:
    if not metrics:
        raise ValueError("metrics cannot be empty")
    keys = sorted(set().union(*(item.keys() for item in metrics)))
    result: dict[str, dict[str, float]] = {}
    for key in keys:
        values = np.asarray([item[key] for item in metrics], dtype=np.float64)
        valid = values[~np.isnan(values)]
        result[key] = {"mean": float(valid.mean()) if valid.size else float("nan"), "standard_deviation": float(valid.std()) if valid.size else float("nan"), "minimum": float(valid.min()) if valid.size else float("nan"), "maximum": float(valid.max()) if valid.size else float("nan"), "number_of_runs": float(valid.size)}
    return result


def evaluate_measurement_agreement(predicted: np.ndarray, reference: np.ndarray) -> dict[str, Any]:
    return agreement_statistics(predicted, reference)
