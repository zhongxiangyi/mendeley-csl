from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
import yaml
from torch.utils.data import DataLoader

from yolo_scm.data.collate import collate_instances
from yolo_scm.data.dataset import YoloInstanceDataset
from yolo_scm.engine.evaluator import EvaluatedInstance, evaluate_instances
from yolo_scm.engine.predictor import Predictor, select_classwise_detections
from yolo_scm.model.parser import build_model


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--paper", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--defaults", type=Path, default=Path("configs/implementation_defaults.yaml"))
    parser.add_argument("--output", type=Path, default=Path("runs/validate/metrics.json"))
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    predictor = Predictor.from_checkpoint(build_model(args.paper, args.defaults), args.weights, device)
    with args.defaults.open("r", encoding="utf-8") as handle:
        defaults_document = yaml.safe_load(handle)
    if not isinstance(defaults_document, dict) or not isinstance(defaults_document.get("implementation_defaults"), dict):
        raise ValueError("implementation defaults configuration is invalid")
    defaults = defaults_document["implementation_defaults"]
    validation_confidence_threshold = float(defaults["validation_confidence_threshold"])
    nms_iou_threshold = float(defaults["nms_iou_threshold"])
    max_detections = int(defaults["max_detections"])
    dataset = YoloInstanceDataset(args.data, "val", args.paper, train=False, defaults_config=args.defaults)
    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_instances)
    predictions: list[EvaluatedInstance] = []
    targets: list[EvaluatedInstance] = []
    for batch_index, batch in enumerate(loader):
        images = batch["images"].to(device)
        with torch.inference_mode():
            output = predictor.model(images)
        selection = select_classwise_detections(output.boxes[0], output.class_logits[0], validation_confidence_threshold, nms_iou_threshold, max_detections)
        masks = predictor.model.decode_instance_masks(output.mask_coefficients[:, selection.indices], output.prototypes, output.boxes[:, selection.indices])[0].cpu().numpy() if selection.indices.numel() else None
        image_id = str(batch_index)
        if masks is not None:
            for local_index, anchor_index in enumerate(selection.indices.cpu().tolist()):
                predictions.append(EvaluatedInstance(image_id, int(selection.class_ids[local_index].item()), float(selection.scores[local_index].item()), masks[local_index] >= 0.5, output.boxes[0, anchor_index].cpu().numpy()))
        target = batch["targets"][0]
        for instance_index in range(target["labels"].shape[0]):
            targets.append(EvaluatedInstance(image_id, int(target["labels"][instance_index]), 1.0, target["masks"][instance_index].numpy().astype(bool), target["boxes"][instance_index].numpy()))
    metrics = evaluate_instances(predictions, targets)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(metrics, indent=2, allow_nan=True), encoding="utf-8")
    print(json.dumps(metrics, allow_nan=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
