from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import onnx
import onnxruntime
import torch
from torch import Tensor, nn

from yolo_scm.engine.predictor import Predictor
from yolo_scm.model.parser import build_model


class OnnxWrapper(nn.Module):
    def __init__(self, model: nn.Module) -> None:
        super().__init__()
        self.model = model

    def forward(self, images: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        output = self.model(images)
        return output.boxes, output.class_logits, output.mask_coefficients, output.prototypes


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", "--paper", dest="paper", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--defaults", type=Path, default=Path("configs/implementation_defaults.yaml"))
    parser.add_argument("--smoke-test", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    if args.weights is None and not args.smoke_test:
        raise ValueError("weights are required unless smoke-test is enabled")
    model = build_model(args.paper, args.defaults).eval()
    if args.weights is not None:
        Predictor.from_checkpoint(model, args.weights, torch.device("cpu"))
    wrapper = OnnxWrapper(model).eval()
    example = torch.zeros((1, 3, 640, 640), dtype=torch.float32)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(wrapper, example, str(args.output), input_names=["images"], output_names=["boxes", "class_logits", "mask_coefficients", "prototypes"], dynamic_axes={"images": {0: "batch"}, "boxes": {0: "batch"}, "class_logits": {0: "batch"}, "mask_coefficients": {0: "batch"}, "prototypes": {0: "batch"}}, opset_version=17, dynamo=False)
    model_onnx = onnx.load(str(args.output))
    onnx.checker.check_model(model_onnx)
    session = onnxruntime.InferenceSession(str(args.output), providers=["CPUExecutionProvider"])
    with torch.inference_mode():
        reference = wrapper(example)
    runtime = session.run(None, {"images": example.numpy()})
    shapes = [list(value.shape) for value in runtime]
    difference = max(float(np.max(np.abs(value.detach().cpu().numpy() - output))) for value, output in zip(reference, runtime))
    result = {"checker": "passed", "runtime": "passed", "output_shapes": shapes, "max_output_difference": difference}
    (args.output.with_suffix(".json")).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
