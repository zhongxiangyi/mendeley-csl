from __future__ import annotations

import argparse
from pathlib import Path

from yolo_scm.calibration.camera import calibrate_camera


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--square-size-mm", type=float, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    images = sorted(path for path in args.images.rglob("*") if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}) if args.images.is_dir() else [args.images]
    calibrate_camera(images, args.square_size_mm, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
