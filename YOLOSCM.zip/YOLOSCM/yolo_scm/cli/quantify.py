from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from yolo_scm.calibration.homography import marker_homography, warp_image_and_mask
from yolo_scm.calibration.scale import scale_from_metadata
from yolo_scm.calibration.validation import validate_measurement
from yolo_scm.quantification.crack import quantify_crack
from yolo_scm.quantification.spalling import quantify_spalling


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mask", type=Path, required=True)
    parser.add_argument("--class-id", type=int, choices=[0, 1], required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--allow-provisional-calibration", action="store_true")
    return parser


def _load_metadata(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("metadata must be a JSON object")
    return value


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    image = cv2.imread(str(args.mask), cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError("unable to read mask")
    metadata = _load_metadata(args.metadata)
    if args.allow_provisional_calibration:
        metadata["allow_provisional_calibration"] = True
    mask = (image > 0).astype(np.uint8)
    if metadata.get("mode") == "ruler":
        scale = scale_from_metadata(metadata)
        measurement_mask = mask
    elif metadata.get("mode") == "planar_marker":
        validation_points = metadata.get("validation_points")
        if validation_points is not None and not isinstance(validation_points, list):
            raise ValueError("validation_points must be a list")
        homography = marker_homography(metadata["corners"], mask.shape, None, float(metadata.get("marker_width_mm", 25.0)), float(metadata.get("marker_height_mm", 30.0)), 20.0, validation_points)
        _, measurement_mask = warp_image_and_mask(np.zeros((*mask.shape, 3), dtype=np.uint8), mask, homography)
        scale = homography.scale
    else:
        scale = None
        measurement_mask = mask
    decision = validate_measurement(metadata, scale)
    if args.class_id == 0:
        result = quantify_crack(measurement_mask, scale if decision.reliable else None, str(metadata.get("environment", "laboratory")))
        result.pop("skeleton")
        result.pop("path")
    else:
        result = quantify_spalling(measurement_mask, scale if decision.reliable else None)
    result["reliability_status"] = decision.status
    result["rejection_reasons"] = decision.reasons
    result["calibration_validation_status"] = None if scale is None else scale.calibration_validation_status
    result["calibration_residual_percent"] = None if scale is None else scale.residual_percent
    result["homography_fitting_residual_percent"] = None if metadata.get("mode") != "planar_marker" else homography.homography_fitting_residual_percent
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, default=lambda value: value.tolist() if isinstance(value, np.ndarray) else value, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
