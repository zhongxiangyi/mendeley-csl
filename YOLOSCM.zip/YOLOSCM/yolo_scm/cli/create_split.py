from __future__ import annotations

import argparse
from pathlib import Path

from yolo_scm.data.group_split import create_group_split


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=2022)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    create_group_split(args.metadata, args.output, args.seed)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
