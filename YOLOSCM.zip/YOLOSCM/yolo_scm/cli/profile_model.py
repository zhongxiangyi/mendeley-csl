from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch import Tensor, nn

from yolo_scm.model.parser import build_model


def profile_model(model: nn.Module, image_size: int = 640) -> tuple[int, float]:
    operations = 0

    def hook(module: nn.Module, inputs: tuple[Tensor, ...], output: Tensor) -> None:
        nonlocal operations
        if isinstance(module, nn.Conv2d):
            batch, channels, height, width = output.shape
            kernel = module.kernel_size[0] * module.kernel_size[1]
            operations += int(2 * batch * channels * height * width * (module.in_channels // module.groups) * kernel)
        elif isinstance(module, nn.Conv1d):
            batch, channels, length = output.shape
            operations += int(2 * batch * channels * length * (module.in_channels // module.groups) * module.kernel_size[0])
        elif isinstance(module, nn.Linear):
            operations += int(2 * output.numel() * module.in_features)

    handles = [module.register_forward_hook(hook) for module in model.modules() if isinstance(module, (nn.Conv1d, nn.Conv2d, nn.Linear))]
    model.eval()
    with torch.inference_mode():
        model(torch.zeros((1, 3, image_size, image_size)))
    for handle in handles:
        handle.remove()
    return sum(parameter.numel() for parameter in model.parameters()), operations / 1e9


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--defaults", type=Path, default=Path("configs/implementation_defaults.yaml"))
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    model = build_model(args.config, args.defaults)
    parameters, gflops = profile_model(model, model.input_size)
    parameter_delta = abs(parameters / 1_000_000.0 - 9.1) / 9.1
    flops_delta = abs(gflops - 26.8) / 26.8
    print(f"parameters_m={parameters / 1_000_000.0:.3f}")
    print(f"gflops={gflops:.3f}")
    print(f"fp16_model_size_mb={parameters * 2 / 1_000_000.0:.3f}")
    if parameter_delta > 0.05 or flops_delta > 0.05:
        print("target_tolerance=failed")
        return 1
    print("target_tolerance=passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
