from __future__ import annotations

import argparse
from pathlib import Path

from yolo_scm.engine.pipeline import run_pipeline


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--confidence", type=float, default=0.25)
    parser.add_argument("--nms-iou", type=float, default=0.7)
    parser.add_argument("--allow-provisional-calibration", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    run_pipeline(args.weights, args.source, args.output, confidence_threshold=args.confidence, nms_iou_threshold=args.nms_iou, allow_provisional_calibration=args.allow_provisional_calibration)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
