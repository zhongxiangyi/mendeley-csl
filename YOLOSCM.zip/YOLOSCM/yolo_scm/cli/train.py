from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from yolo_scm.engine.trainer import train_many, train_seed
from yolo_scm.model.parser import build_model


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--paper", type=Path, default=Path("configs/paper.yaml"))
    parser.add_argument("--defaults", type=Path, default=Path("configs/implementation_defaults.yaml"))
    parser.add_argument("--output", type=Path, default=Path("runs/train"))
    parser.add_argument("--seed", type=int, default=2022)
    parser.add_argument("--all-seeds", action="store_true")
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--max-epochs", type=int)
    parser.add_argument("--pretrained", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    if args.max_epochs is not None and args.max_epochs <= 0:
        raise ValueError("max-epochs must be positive")
    if args.all_seeds and args.resume is not None:
        raise ValueError("resume is only supported in single-seed mode")
    with args.defaults.open("r", encoding="utf-8") as handle:
        defaults_document = yaml.safe_load(handle)
    if not isinstance(defaults_document, dict) or not isinstance(defaults_document.get("implementation_defaults"), dict):
        raise ValueError("implementation defaults configuration is invalid")
    configured_pretrained = defaults_document["implementation_defaults"].get("pretrained_weights")
    pretrained = args.pretrained if args.pretrained is not None else (Path(configured_pretrained) if configured_pretrained else None)
    def factory() -> object:
        model = build_model(args.paper, args.defaults)
        if pretrained is not None:
            print(model.load_pretrained(pretrained))
        return model
    if args.all_seeds:
        train_many(factory, args.data, args.paper, args.defaults, args.output)
    else:
        train_seed(factory(), args.data, args.paper, args.defaults, args.output, args.seed, args.resume, args.max_epochs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
