from __future__ import annotations

import argparse
from pathlib import Path

from yolo_scm.engine.pipeline import run_pipeline


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--camera-calibration", type=Path)
    parser.add_argument("--measurement-metadata", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--confidence", type=float, default=0.25)
    parser.add_argument("--nms-iou", type=float, default=0.7)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--allow-provisional-calibration", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    if not 0.0 <= args.confidence <= 1.0 or not 0.0 <= args.nms_iou <= 1.0:
        raise ValueError("confidence and nms-iou must be between zero and one")
    run_pipeline(args.weights, args.source, args.output, args.camera_calibration, args.measurement_metadata, args.confidence, args.nms_iou, args.smoke_test, args.allow_provisional_calibration)
    print("smoke-test passed" if args.smoke_test else "pipeline completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
