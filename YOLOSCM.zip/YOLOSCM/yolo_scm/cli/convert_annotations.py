from __future__ import annotations

import argparse
from pathlib import Path

from yolo_scm.data.xanylabeling_converter import convert_xanylabeling_json


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    convert_xanylabeling_json(args.source, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
