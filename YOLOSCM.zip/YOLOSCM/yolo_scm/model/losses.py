from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import torch
from torch import Tensor, nn
from torch.nn import functional as functional
from ultralytics.utils.loss import BboxLoss
from ultralytics.utils.tal import TaskAlignedAssigner, make_anchors

from yolo_scm.model.network import ModelOutput


@dataclass
class AssignmentResult:
    foreground_mask: Tensor
    target_indices: Tensor
    target_boxes: Tensor
    target_scores: Tensor
    anchor_points: Tensor
    stride_tensor: Tensor
    labels: Tensor
    masks: list[Tensor]


@dataclass
class LossResult:
    total: Tensor
    box: Tensor
    cls: Tensor
    dfl: Tensor
    mask: Tensor
    dice: Tensor
    boundary: Tensor
    assignment: AssignmentResult


def boundary_band(mask: Tensor, band_width_pixels: int = 3) -> Tensor:
    if mask.ndim == 4:
        batch, count, height, image_width = mask.shape
        return boundary_band(mask.reshape(batch * count, height, image_width), band_width_pixels).reshape(batch, count, height, image_width)
    if mask.ndim != 3:
        raise ValueError("mask must have shape NxHxW or BxNxHxW")
    if band_width_pixels <= 0 or band_width_pixels % 2 == 0:
        raise ValueError("band_width_pixels must be a positive odd integer")
    radius = (band_width_pixels - 1) // 2
    flat = mask.unsqueeze(1).float()
    dilation = functional.max_pool2d(flat, band_width_pixels, 1, radius)
    erosion = -functional.max_pool2d(-flat, band_width_pixels, 1, radius)
    return (dilation - erosion).clamp(0, 1).squeeze(1)


def dice_loss(logits: Tensor, targets: Tensor, regions: Tensor) -> Tensor:
    probabilities = torch.sigmoid(logits) * regions
    masked_targets = targets * regions
    numerator = 2.0 * (probabilities * masked_targets).sum(dim=(-2, -1)) + 1e-6
    denominator = probabilities.sum(dim=(-2, -1)) + masked_targets.sum(dim=(-2, -1)) + 1e-6
    return (1.0 - numerator / denominator).mean()


def _crop_regions(boxes: Tensor, mask_height: int, mask_width: int, image_height: int, image_width: int) -> Tensor:
    y = torch.arange(mask_height, device=boxes.device).view(1, mask_height, 1)
    x = torch.arange(mask_width, device=boxes.device).view(1, 1, mask_width)
    scaled = boxes.clone()
    scaled[:, [0, 2]] *= float(mask_width) / float(image_width)
    scaled[:, [1, 3]] *= float(mask_height) / float(image_height)
    return ((x >= scaled[:, 0, None, None]) & (x < scaled[:, 2, None, None]) & (y >= scaled[:, 1, None, None]) & (y < scaled[:, 3, None, None])).float()


class YoloScmLoss(nn.Module):
    def __init__(self, weights: Mapping[str, float], num_classes: int = 2, reg_max: int = 16) -> None:
        super().__init__()
        expected = {"box", "cls", "dfl", "mask", "dice", "boundary"}
        if set(weights) != expected:
            raise ValueError("loss weights must define box, cls, dfl, mask, dice and boundary")
        self.weights = {key: float(value) for key, value in weights.items()}
        self.num_classes = num_classes
        self.reg_max = reg_max
        self.assigner = TaskAlignedAssigner(topk=10, num_classes=num_classes, alpha=0.5, beta=6.0)
        self.bce = nn.BCEWithLogitsLoss(reduction="none")
        self.bbox_loss = BboxLoss(reg_max)

    def assign(self, predictions: ModelOutput, targets: list[dict[str, Tensor]]) -> AssignmentResult:
        if len(targets) != predictions.boxes.shape[0]:
            raise ValueError("target batch size does not match prediction batch size")
        device = predictions.boxes.device
        batch_size, anchor_count, _ = predictions.boxes.shape
        max_targets = max((int(target["boxes"].shape[0]) for target in targets), default=0)
        labels = torch.zeros((batch_size, max_targets, 1), device=device)
        boxes = torch.zeros((batch_size, max_targets, 4), device=device)
        valid = torch.zeros((batch_size, max_targets, 1), dtype=torch.bool, device=device)
        masks: list[Tensor] = []
        for index, target in enumerate(targets):
            target_boxes = target["boxes"].to(device).float()
            target_labels = target["labels"].to(device).long()
            target_masks = target["masks"].to(device).float()
            if target_boxes.ndim != 2 or target_boxes.shape[-1] != 4 or target_labels.ndim != 1 or target_masks.ndim != 3:
                raise ValueError("targets must contain boxes Nx4, labels N and masks NxHxW")
            if target_boxes.shape[0] != target_labels.shape[0] or target_boxes.shape[0] != target_masks.shape[0]:
                raise ValueError("target boxes, labels and masks must have matching instance counts")
            if torch.any(target_labels < 0) or torch.any(target_labels >= self.num_classes):
                raise ValueError("target class id is invalid")
            count = target_boxes.shape[0]
            if count:
                labels[index, :count, 0] = target_labels
                boxes[index, :count] = target_boxes
                valid[index, :count, 0] = True
            masks.append(target_masks)
        anchor_points, stride_tensor = make_anchors(list(predictions.raw["feats"]), predictions.strides.reshape(-1).unique_consecutive(), 0.5)
        result = self.assigner(predictions.class_logits.detach().sigmoid(), predictions.boxes.detach(), anchor_points * stride_tensor, labels, boxes, valid)
        _, target_boxes, target_scores, foreground_mask, target_indices = result
        if foreground_mask.shape != (batch_size, anchor_count):
            raise RuntimeError("assigner returned an invalid foreground mask")
        return AssignmentResult(foreground_mask.bool(), target_indices.long(), target_boxes, target_scores, anchor_points, stride_tensor, labels, masks)

    def forward(self, predictions: ModelOutput, targets: list[dict[str, Tensor]]) -> LossResult:
        assignment = self.assign(predictions, targets)
        device = predictions.boxes.device
        zero = predictions.boxes.sum() * 0.0
        score_sum = assignment.target_scores.sum().clamp_min(1.0)
        cls = self.bce(predictions.class_logits, assignment.target_scores.to(predictions.class_logits.dtype)).sum() / score_sum
        box = zero
        dfl = zero
        if assignment.foreground_mask.any():
            image_height = int(predictions.features[0].shape[-2] * 8)
            image_width = int(predictions.features[0].shape[-1] * 8)
            box, dfl = self.bbox_loss(predictions.raw["boxes"].permute(0, 2, 1).contiguous(), predictions.boxes / assignment.stride_tensor, assignment.anchor_points, assignment.target_boxes / assignment.stride_tensor, assignment.target_scores, score_sum, assignment.foreground_mask, torch.tensor((image_height, image_width), device=device, dtype=predictions.boxes.dtype), assignment.stride_tensor)
        mask, dice, boundary = self._instance_mask_losses(predictions, assignment)
        total = self.weights["box"] * box + self.weights["cls"] * cls + self.weights["dfl"] * dfl + self.weights["mask"] * mask + self.weights["dice"] * dice + self.weights["boundary"] * boundary
        return LossResult(total, box, cls, dfl, mask, dice, boundary, assignment)

    def _instance_mask_losses(self, predictions: ModelOutput, assignment: AssignmentResult) -> tuple[Tensor, Tensor, Tensor]:
        zero = predictions.prototypes.sum() * 0.0
        if not assignment.foreground_mask.any():
            return zero, zero, zero
        image_height = int(predictions.features[0].shape[-2] * 8)
        image_width = int(predictions.features[0].shape[-1] * 8)
        bce_values: list[Tensor] = []
        dice_values: list[Tensor] = []
        boundary_values: list[Tensor] = []
        for batch_index in range(predictions.boxes.shape[0]):
            foreground = assignment.foreground_mask[batch_index]
            if not foreground.any():
                continue
            instance_indices = assignment.target_indices[batch_index, foreground]
            source_masks = assignment.masks[batch_index]
            if source_masks.shape[0] == 0:
                raise RuntimeError("foreground assignment exists without source masks")
            target_masks = source_masks[instance_indices]
            prototype = predictions.prototypes[batch_index]
            coefficients = predictions.mask_coefficients[batch_index, foreground]
            logits = torch.einsum("nm,mhw->nhw", coefficients, prototype)
            target_masks = functional.interpolate(target_masks.unsqueeze(1), logits.shape[-2:], mode="nearest").squeeze(1)
            regions = _crop_regions(assignment.target_boxes[batch_index, foreground], logits.shape[-2], logits.shape[-1], image_height, image_width)
            bce = functional.binary_cross_entropy_with_logits(logits, target_masks, reduction="none")
            bce_values.append((bce * regions).sum() / regions.sum().clamp_min(1.0))
            dice_values.append(dice_loss(logits, target_masks, regions))
            edges_predicted = torch.abs(torch.sigmoid(logits) - functional.avg_pool2d(torch.sigmoid(logits).unsqueeze(1), 3, 1, 1).squeeze(1))
            edges_target = torch.abs(target_masks - functional.avg_pool2d(target_masks.unsqueeze(1), 3, 1, 1).squeeze(1))
            band = boundary_band(target_masks)
            boundary_values.append(((edges_predicted - edges_target).abs() * band * regions).sum() / (band * regions).sum().clamp_min(1.0))
        if not bce_values:
            return zero, zero, zero
        return torch.stack(bce_values).mean(), torch.stack(dice_values).mean(), torch.stack(boundary_values).mean()
