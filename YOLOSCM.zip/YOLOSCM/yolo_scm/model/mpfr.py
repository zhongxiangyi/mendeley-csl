from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from yolo_scm.model.common import ConvBNAct


class MPFR(nn.Module):
    def __init__(self, channels: int, token_size: int = 4) -> None:
        super().__init__()
        if channels <= 0 or token_size != 4:
            raise ValueError("channels must be positive and token_size must be 4")
        branch_channels = max(16, channels // 8)
        token_channels = channels * token_size * token_size
        branch_token_channels = branch_channels * token_size * token_size
        self.channels = channels
        self.branch_channels = branch_channels
        self.token_size = token_size
        self.line_projection = nn.Conv1d(token_channels, branch_token_channels, 1, groups=branch_channels, bias=False)
        self.boundary_projection = nn.Conv1d(token_channels, branch_token_channels, 1, groups=branch_channels, bias=False)
        self.texture_projection = nn.Conv1d(token_channels, branch_token_channels, 1, groups=branch_channels, bias=False)
        self.line_horizontal = ConvBNAct(branch_channels, branch_channels, (1, 3), groups=branch_channels)
        self.line_vertical = ConvBNAct(branch_channels, branch_channels, (3, 1), groups=branch_channels)
        self.line_attention = nn.Conv2d(branch_channels, branch_channels, 1)
        self.boundary_depthwise = ConvBNAct(branch_channels, branch_channels, 3, groups=branch_channels, dilation=2)
        self.boundary_attention = nn.Conv2d(branch_channels, branch_channels, 1)
        self.texture_depthwise = ConvBNAct(branch_channels, branch_channels, 3, groups=branch_channels)
        self.texture_attention = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(branch_channels, branch_channels, 1), nn.Sigmoid())
        self.weight_gate = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(channels, max(16, channels // 8), 1), nn.SiLU(inplace=True), nn.Conv2d(max(16, channels // 8), 3, 1))
        self.reconstruct = ConvBNAct(branch_channels * 3, channels, 1)
        self.last_weights: Tensor | None = None

    def _pad(self, value: Tensor) -> tuple[Tensor, int, int]:
        height, width = value.shape[-2:]
        bottom = (-height) % self.token_size
        right = (-width) % self.token_size
        return functional.pad(value, (0, right, 0, bottom)), bottom, right

    def unfold_tokens(self, value: Tensor) -> tuple[Tensor, tuple[int, int]]:
        if value.ndim != 4:
            raise ValueError("value must have shape BxCxHxW")
        height, width = value.shape[-2:]
        if height % self.token_size != 0 or width % self.token_size != 0:
            raise ValueError("unfold_tokens requires dimensions divisible by token_size")
        return functional.unfold(value, self.token_size, stride=self.token_size), (height, width)

    def fold_tokens(self, tokens: Tensor, output_size: tuple[int, int]) -> Tensor:
        if tokens.ndim != 3:
            raise ValueError("tokens must have shape BxCxL")
        folded = functional.fold(tokens, output_size, self.token_size, stride=self.token_size)
        normalizer = functional.fold(torch.ones((tokens.shape[0], self.token_size * self.token_size, tokens.shape[-1]), dtype=tokens.dtype, device=tokens.device), output_size, self.token_size, stride=self.token_size)
        return folded / normalizer.clamp_min(torch.finfo(tokens.dtype).eps)

    def _reorganize(self, tokens: Tensor, height: int, width: int) -> Tensor:
        batch = tokens.shape[0]
        grid_height, grid_width = height // self.token_size, width // self.token_size
        return tokens.reshape(batch, self.branch_channels, self.token_size, self.token_size, grid_height, grid_width).permute(0, 1, 4, 2, 5, 3).reshape(batch, self.branch_channels, height, width)

    def _retokenize(self, feature: Tensor) -> Tensor:
        return functional.unfold(feature, self.token_size, stride=self.token_size)

    def _branch(self, tokens: Tensor, height: int, width: int, branch: str) -> Tensor:
        feature = self._reorganize(tokens, height, width)
        if branch == "line":
            feature = feature * torch.sigmoid(self.line_attention(self.line_horizontal(feature) + self.line_vertical(feature)))
        elif branch == "boundary":
            feature = feature * torch.sigmoid(self.boundary_attention(self.boundary_depthwise(feature)))
        elif branch == "texture":
            feature = self.texture_depthwise(feature) * self.texture_attention(feature)
        else:
            raise ValueError("unknown MPFR branch")
        return self._reorganize(self._retokenize(feature), height, width)

    def forward(self, value: Tensor) -> Tensor:
        if value.ndim != 4 or value.shape[1] != self.channels:
            raise ValueError(f"expected Bx{self.channels}xHxW input")
        padded, bottom, right = self._pad(value)
        height, width = padded.shape[-2:]
        tokens, _ = self.unfold_tokens(padded)
        line = self._branch(self.line_projection(tokens), height, width, "line")
        boundary = self._branch(self.boundary_projection(tokens), height, width, "boundary")
        texture = self._branch(self.texture_projection(tokens), height, width, "texture")
        weights = torch.softmax(self.weight_gate(padded).flatten(2).mean(dim=2), dim=1)
        self.last_weights = weights
        output = self.reconstruct(torch.cat((weights[:, 0, None, None, None] * line, weights[:, 1, None, None, None] * boundary, weights[:, 2, None, None, None] * texture), dim=1))
        return output[:, :, : value.shape[-2], : value.shape[-1]] if bottom != 0 or right != 0 else output
