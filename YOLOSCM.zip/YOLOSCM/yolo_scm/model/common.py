from __future__ import annotations

from typing import Sequence

from torch import Tensor, nn


def autopad(kernel_size: int | Sequence[int], dilation: int = 1) -> int | tuple[int, int]:
    if isinstance(kernel_size, int):
        return dilation * (kernel_size - 1) // 2
    return tuple(dilation * (value - 1) // 2 for value in kernel_size)


class ConvBNAct(nn.Module):
    def __init__(self, c1: int, c2: int, kernel_size: int | Sequence[int] = 1, stride: int = 1, groups: int = 1, dilation: int = 1, activation: bool = True) -> None:
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, kernel_size, stride, autopad(kernel_size, dilation), dilation, groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if activation else nn.Identity()

    def forward(self, value: Tensor) -> Tensor:
        return self.act(self.bn(self.conv(value)))


class ResidualBottleneck(nn.Module):
    def __init__(self, channels: int, shortcut: bool = True, kernel_size: int = 3) -> None:
        super().__init__()
        self.cv1 = ConvBNAct(channels, channels, 1)
        self.cv2 = ConvBNAct(channels, channels, kernel_size)
        self.shortcut = shortcut

    def forward(self, value: Tensor) -> Tensor:
        output = self.cv2(self.cv1(value))
        return value + output if self.shortcut else output


class Downsample(nn.Module):
    def __init__(self, c1: int, c2: int) -> None:
        super().__init__()
        self.depthwise = ConvBNAct(c1, c1, 3, 2, groups=c1)
        self.pointwise = ConvBNAct(c1, c2, 1)

    def forward(self, value: Tensor) -> Tensor:
        return self.pointwise(self.depthwise(value))


def channel_shuffle(value: Tensor, groups: int) -> Tensor:
    batch, channels, height, width = value.shape
    if channels % groups != 0:
        raise ValueError(f"channels={channels} is not divisible by groups={groups}")
    return value.reshape(batch, groups, channels // groups, height, width).transpose(1, 2).reshape(batch, channels, height, width)


def make_divisible(value: int, divisor: int) -> int:
    return max(divisor, int((value + divisor / 2) // divisor * divisor))
