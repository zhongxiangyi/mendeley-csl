from __future__ import annotations

from pathlib import Path
from typing import Any

import ultralytics
import yaml

from yolo_scm.model.network import NetworkConfig, YoloScm


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"configuration at {path} must be a mapping")
    return value


def _mapping(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be a mapping")
    return value


def _structure_path(paper_path: Path, reference: Any) -> Path:
    if not isinstance(reference, str) or not reference:
        raise ValueError("model.structure_config must be a non-empty path")
    configured = Path(reference)
    candidates = [configured] if configured.is_absolute() else [paper_path.parent / configured, configured]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(configured)


def build_network_config(paper_config: Path, defaults_config: Path) -> NetworkConfig:
    paper = load_yaml(paper_config)
    defaults = _mapping(load_yaml(defaults_config).get("implementation_defaults"), "implementation_defaults")
    model = _mapping(paper.get("model"), "model")
    structure = _mapping(load_yaml(_structure_path(paper_config, model.get("structure_config"))).get("architecture"), "architecture")
    if structure.get("base_model") != "yolov10s":
        raise ValueError("YOLO-SCM requires the official yolov10s base model")
    load_yolov10s_config()
    channels = _mapping(structure.get("channels"), "architecture.channels")
    repeats = _mapping(structure.get("repeats"), "architecture.repeats")
    channel_names = {"stem", "stage2", "p3", "p4", "p5"}
    repeat_names = {"stage2", "p3", "p4", "p5", "neck_p4", "neck_p3", "neck_bottom", "neck_p5"}
    if set(channels) != channel_names or set(repeats) != repeat_names:
        raise ValueError("YOLO-SCM architecture channels or repeats are incomplete")
    parsed_channels = {name: int(channels[name]) for name in channel_names}
    parsed_repeats = {name: int(repeats[name]) for name in repeat_names}
    if any(value <= 0 for value in parsed_channels.values()) or any(value <= 0 for value in parsed_repeats.values()):
        raise ValueError("architecture channels and repeats must be positive")
    csdmf = _mapping(model.get("csdmf"), "model.csdmf")
    required_csdmf = {"input_channels", "aligned_channels", "output_channels", "fusion_levels", "strip_kernel_horizontal", "strip_kernel_vertical", "dilation_rates"}
    if set(csdmf) != required_csdmf:
        raise ValueError("model.csdmf must contain only the configured CSDMF parameters")
    parsed_csdmf = {
        "input_channels": int(csdmf["input_channels"]),
        "aligned_channels": int(csdmf["aligned_channels"]),
        "output_channels": int(csdmf["output_channels"]),
        "fusion_levels": int(csdmf["fusion_levels"]),
        "strip_kernel_horizontal": tuple(int(value) for value in csdmf["strip_kernel_horizontal"]),
        "strip_kernel_vertical": tuple(int(value) for value in csdmf["strip_kernel_vertical"]),
        "dilation_rates": tuple(int(value) for value in csdmf["dilation_rates"]),
    }
    if parsed_csdmf["input_channels"] != parsed_channels["p5"] or parsed_csdmf["aligned_channels"] != 256 or parsed_csdmf["output_channels"] != 256 or parsed_csdmf["fusion_levels"] != 3 or parsed_csdmf["strip_kernel_horizontal"] != (1, 7) or parsed_csdmf["strip_kernel_vertical"] != (7, 1) or parsed_csdmf["dilation_rates"] != (2, 3):
        raise ValueError("CSDMF configuration does not match the fixed YOLO-SCM settings")
    class_names = tuple(str(value) for value in model.get("class_names", []))
    if class_names != ("crack", "spalling"):
        raise ValueError("model.class_names must be crack and spalling")
    return NetworkConfig(int(model["input_size"]), int(model["num_classes"]), class_names, int(model["attention_groups"]), int(model["c3k2sa_kernel_size"]), parsed_channels, parsed_repeats, parsed_csdmf, int(_mapping(model.get("mpfr"), "model.mpfr")["token_size"]), int(defaults["mask_prototype_dim"]), int(defaults["segment_prototype_channels"]), int(defaults["reg_max"]), float(defaults["c3_expansion"]))


def build_model(paper_config: Path, defaults_config: Path) -> YoloScm:
    return YoloScm(build_network_config(paper_config, defaults_config))


def load_yolov10s_config() -> dict[str, Any]:
    path = Path(ultralytics.__file__).resolve().parent / "cfg" / "models" / "v10" / "yolov10s.yaml"
    if not path.exists():
        raise FileNotFoundError("official Ultralytics YOLOv10s configuration is unavailable")
    value = load_yaml(path)
    if "backbone" not in value or "head" not in value:
        raise ValueError("official YOLOv10s configuration is invalid")
    return value
