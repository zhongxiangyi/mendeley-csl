from __future__ import annotations

import torch
from torch import Tensor, nn

from yolo_scm.model.common import channel_shuffle


class ShuffleAttention(nn.Module):
    def __init__(self, channels: int, groups: int = 8) -> None:
        super().__init__()
        if channels % (2 * groups) != 0:
            raise ValueError(f"channels={channels} must be divisible by 2*groups={2 * groups}")
        half_channels = channels // (2 * groups)
        reduced_channels = max(1, half_channels // 2)
        self.channels = channels
        self.groups = groups
        self.half_channels = half_channels
        self.channel_reduce = nn.Conv2d(half_channels, reduced_channels, 1, bias=True)
        self.channel_expand = nn.Conv2d(reduced_channels, half_channels, 1, bias=True)
        self.spatial_norm = nn.GroupNorm(1, half_channels)
        self.spatial_weight = nn.Conv2d(half_channels, half_channels, 1, bias=True)

    def forward(self, value: Tensor) -> Tensor:
        batch, channels, height, width = value.shape
        if channels != self.channels:
            raise ValueError(f"expected {self.channels} channels, received {channels}")
        grouped = value.reshape(batch * self.groups, 2 * self.half_channels, height, width)
        channel_part, spatial_part = grouped.chunk(2, dim=1)
        pooled = torch.mean(channel_part, dim=(2, 3), keepdim=True)
        channel_attention = torch.sigmoid(self.channel_expand(torch.relu(self.channel_reduce(pooled))))
        spatial_attention = torch.sigmoid(self.spatial_weight(self.spatial_norm(spatial_part)))
        output = torch.cat((channel_part * channel_attention, spatial_part * spatial_attention), dim=1)
        output = output.reshape(batch, channels, height, width)
        return channel_shuffle(output, 2)
