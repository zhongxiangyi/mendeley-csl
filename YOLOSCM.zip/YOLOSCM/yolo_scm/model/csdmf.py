from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from yolo_scm.model.common import ConvBNAct


class CSDMF(nn.Module):
    def __init__(self, input_channels: int, p4_channels: int, p3_channels: int, aligned_channels: int, output_channels: int, strip_kernel_horizontal: tuple[int, int], strip_kernel_vertical: tuple[int, int], dilation_rates: tuple[int, int]) -> None:
        super().__init__()
        if input_channels <= 0 or p4_channels <= 0 or p3_channels <= 0 or aligned_channels <= 0 or output_channels != aligned_channels:
            raise ValueError("CSDMF channel configuration is invalid")
        if strip_kernel_horizontal != (1, 7) or strip_kernel_vertical != (7, 1) or dilation_rates != (2, 3):
            raise ValueError("CSDMF kernels and dilation rates must match the fixed configuration")
        self.input_channels = input_channels
        self.output_channels = output_channels
        self.p3_align = ConvBNAct(p3_channels, aligned_channels, 1)
        self.p4_align = ConvBNAct(p4_channels, aligned_channels, 1)
        self.p5_align = ConvBNAct(input_channels, aligned_channels, 1)
        self.fuse = ConvBNAct(aligned_channels * 3, aligned_channels, 1)
        self.line_horizontal = ConvBNAct(aligned_channels, aligned_channels, strip_kernel_horizontal, groups=aligned_channels)
        self.line_vertical = ConvBNAct(aligned_channels, aligned_channels, strip_kernel_vertical)
        self.line_gate = nn.Conv2d(aligned_channels, aligned_channels, 1)
        self.region_d2 = ConvBNAct(aligned_channels, aligned_channels, 3, groups=aligned_channels, dilation=dilation_rates[0])
        self.region_d3 = ConvBNAct(aligned_channels, aligned_channels, 3, groups=aligned_channels, dilation=dilation_rates[1])
        self.region_context = ConvBNAct(aligned_channels, aligned_channels, 3)
        self.boundary_refine = ConvBNAct(aligned_channels, aligned_channels, 3)
        self.background_context = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(aligned_channels, aligned_channels, 1), nn.SiLU(inplace=True), nn.Conv2d(aligned_channels, aligned_channels, 1))
        descriptor_channels = aligned_channels * 3
        hidden = max(16, descriptor_channels // 8)
        self.gate = nn.Sequential(nn.Linear(descriptor_channels, hidden), nn.SiLU(inplace=True), nn.Linear(hidden, 3))
        self.last_weights: Tensor | None = None

    def forward(self, p5: Tensor, p4: Tensor, p3: Tensor) -> Tensor:
        if p5.shape[1] != self.input_channels:
            raise ValueError("P5 channels do not match CSDMF input_channels")
        target_size = p5.shape[-2:]
        p5_feature = self.p5_align(p5)
        p4_feature = functional.interpolate(self.p4_align(p4), size=target_size, mode="bilinear", align_corners=False)
        p3_feature = functional.interpolate(self.p3_align(p3), size=target_size, mode="bilinear", align_corners=False)
        fused = self.fuse(torch.cat((p3_feature, p4_feature, p5_feature), dim=1))
        line_feature = self.line_horizontal(fused) + self.line_vertical(fused)
        crack_branch = line_feature * torch.sigmoid(self.line_gate(line_feature))
        region_feature = self.region_d2(fused) + self.region_d3(fused)
        spalling_branch = self.boundary_refine(self.region_context(region_feature) + region_feature)
        context = self.background_context(fused)
        background_branch = fused * (1.0 - torch.sigmoid(context))
        descriptor = functional.adaptive_avg_pool2d(torch.cat((crack_branch, spalling_branch, background_branch), dim=1), 1).flatten(1)
        weights = torch.softmax(self.gate(descriptor), dim=1)
        self.last_weights = weights
        return weights[:, 0, None, None, None] * crack_branch + weights[:, 1, None, None, None] * spalling_branch + weights[:, 2, None, None, None] * background_branch
