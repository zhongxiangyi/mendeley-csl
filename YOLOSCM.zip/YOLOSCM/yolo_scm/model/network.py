from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping

import torch
from torch import Tensor, nn
from torch.nn import functional as functional
from ultralytics.nn.modules import C2f, Conv, PSA, SCDown, Segment
from ultralytics.utils.tal import make_anchors

from yolo_scm.model.c3k2sa import C3K2SA
from yolo_scm.model.csdmf import CSDMF
from yolo_scm.model.mpfr import MPFR


@dataclass(frozen=True)
class NetworkConfig:
    input_size: int
    num_classes: int
    class_names: tuple[str, str]
    attention_groups: int
    c3k2sa_kernel_size: int
    channels: dict[str, int]
    repeats: dict[str, int]
    csdmf: dict[str, Any]
    mpfr_token_size: int
    prototype_dim: int
    segment_prototype_channels: int
    reg_max: int
    expansion: float


@dataclass
class ModelOutput:
    boxes: Tensor
    class_logits: Tensor
    mask_coefficients: Tensor
    prototypes: Tensor
    dfl_logits: Tensor
    strides: Tensor
    raw: dict[str, Tensor]
    features: tuple[Tensor, Tensor, Tensor]


class YoloScm(nn.Module):
    def __init__(self, config: NetworkConfig) -> None:
        super().__init__()
        if config.input_size != 640:
            raise ValueError("YOLO-SCM requires a 640 pixel input size")
        if config.num_classes != 2 or config.class_names != ("crack", "spalling"):
            raise ValueError("YOLO-SCM requires crack and spalling classes")
        if config.csdmf["input_channels"] != config.channels["p5"]:
            raise ValueError("CSDMF input_channels must equal the P5 channel count")
        if config.csdmf["fusion_levels"] != 3:
            raise ValueError("CSDMF requires three fusion levels")
        self.config = config
        self.num_classes = config.num_classes
        self.prototype_dim = config.prototype_dim
        self.reg_max = config.reg_max
        self.input_size = config.input_size
        self.args = SimpleNamespace(box=1.0, cls=1.0, dfl=1.0, overlap_mask=False)
        self.names = dict(enumerate(config.class_names))
        channels = config.channels
        repeats = config.repeats
        groups = config.attention_groups
        kernel_size = config.c3k2sa_kernel_size
        expansion = config.expansion
        self.stem = Conv(3, channels["stem"], 3, 2)
        self.stage2_down = Conv(channels["stem"], channels["stage2"], 3, 2)
        self.stage2 = C2f(channels["stage2"], channels["stage2"], repeats["stage2"], True)
        self.p3_down = Conv(channels["stage2"], channels["p3"], 3, 2)
        self.p3 = C3K2SA(channels["p3"], channels["p3"], repeats["p3"], expansion, groups, kernel_size)
        self.p4_down = SCDown(channels["p3"], channels["p4"], 3, 2)
        self.p4 = C3K2SA(channels["p4"], channels["p4"], repeats["p4"], expansion, groups, kernel_size)
        self.p5_down = SCDown(channels["p4"], channels["p5"], 3, 2)
        self.p5 = C3K2SA(channels["p5"], channels["p5"], repeats["p5"], expansion, groups, kernel_size)
        self.csdmf = CSDMF(channels["p5"], channels["p4"], channels["p3"], int(config.csdmf["aligned_channels"]), int(config.csdmf["output_channels"]), tuple(config.csdmf["strip_kernel_horizontal"]), tuple(config.csdmf["strip_kernel_vertical"]), tuple(config.csdmf["dilation_rates"]))
        self.p5_restore = Conv(int(config.csdmf["output_channels"]), channels["p5"], 1, 1)
        self.psa = PSA(channels["p5"], channels["p5"])
        self.mpfr_top = MPFR(channels["p5"] + channels["p4"], config.mpfr_token_size)
        self.neck_p4 = C3K2SA(channels["p5"] + channels["p4"], channels["p4"], repeats["neck_p4"], expansion, groups, kernel_size)
        self.mpfr_mid = MPFR(channels["p4"] + channels["p3"], config.mpfr_token_size)
        self.neck_p3 = C3K2SA(channels["p4"] + channels["p3"], channels["p3"], repeats["neck_p3"], expansion, groups, kernel_size)
        self.down_p3 = Conv(channels["p3"], channels["p3"], 3, 2)
        self.mpfr_bottom = MPFR(channels["p3"] + channels["p4"], config.mpfr_token_size)
        self.neck_bottom = C3K2SA(channels["p3"] + channels["p4"], channels["p4"], repeats["neck_bottom"], expansion, groups, kernel_size)
        self.down_p4 = SCDown(channels["p4"], channels["p4"], 3, 2)
        self.mpfr_out = MPFR(channels["p4"] + channels["p5"], config.mpfr_token_size)
        self.neck_p5 = C3K2SA(channels["p4"] + channels["p5"], channels["p5"], repeats["neck_p5"], expansion, groups, kernel_size)
        self.head = Segment(config.num_classes, config.prototype_dim, config.segment_prototype_channels, config.reg_max, False, (channels["p3"], channels["p4"], channels["p5"]))
        self.stride = torch.tensor((8.0, 16.0, 32.0))
        self.head.stride = self.stride.clone()
        self.head.bias_init()

    def _raw_forward(self, images: Tensor) -> tuple[dict[str, Tensor], tuple[Tensor, Tensor, Tensor]]:
        if images.ndim != 4 or images.shape[1] != 3:
            raise ValueError("images must have shape Bx3xHxW")
        if images.shape[-2:] != (self.input_size, self.input_size):
            raise ValueError(f"images must have shape Bx3x{self.input_size}x{self.input_size}")
        stem = self.stem(images)
        stage2 = self.stage2(self.stage2_down(stem))
        p3 = self.p3(self.p3_down(stage2))
        p4 = self.p4(self.p4_down(p3))
        p5 = self.p5(self.p5_down(p4))
        p5 = self.psa(self.p5_restore(self.csdmf(p5, p4, p3)))
        top = self.neck_p4(self.mpfr_top(torch.cat((functional.interpolate(p5, scale_factor=2.0, mode="nearest"), p4), dim=1)))
        small = self.neck_p3(self.mpfr_mid(torch.cat((functional.interpolate(top, scale_factor=2.0, mode="nearest"), p3), dim=1)))
        medium = self.neck_bottom(self.mpfr_bottom(torch.cat((self.down_p3(small), top), dim=1)))
        large = self.neck_p5(self.mpfr_out(torch.cat((self.down_p4(medium), p5), dim=1)))
        head_output = self.head([small, medium, large])
        if isinstance(head_output, dict):
            return head_output, (small, medium, large)
        if isinstance(head_output, tuple) and isinstance(head_output[-1], dict):
            return head_output[-1], (small, medium, large)
        raise RuntimeError("Ultralytics Segment head did not provide raw predictions")

    def forward(self, images: Tensor) -> ModelOutput:
        raw, features = self._raw_forward(images)
        required = {"boxes", "scores", "mask_coefficient", "proto", "feats"}
        missing = required.difference(raw)
        if missing:
            raise RuntimeError(f"Segment head raw output missing keys: {sorted(missing)}")
        pred_distribution = raw["boxes"].permute(0, 2, 1).contiguous()
        anchor_points, stride_tensor = make_anchors(list(raw["feats"]), self.head.stride, 0.5)
        distributions = pred_distribution.reshape(pred_distribution.shape[0], pred_distribution.shape[1], 4, self.reg_max).softmax(3)
        bins = torch.arange(self.reg_max, device=images.device, dtype=distributions.dtype)
        distances = distributions.matmul(bins)
        anchor = anchor_points.unsqueeze(0)
        decoded = torch.cat((anchor - distances[..., :2], anchor + distances[..., 2:]), dim=-1) * stride_tensor.unsqueeze(0)
        return ModelOutput(decoded, raw["scores"].permute(0, 2, 1).contiguous(), raw["mask_coefficient"].permute(0, 2, 1).contiguous(), raw["proto"], distributions, stride_tensor, raw, features)

    def decode_masks(self, coefficients: Tensor, prototypes: Tensor, output_size: tuple[int, int] | None = None) -> Tensor:
        if coefficients.ndim != 3 or prototypes.ndim != 4:
            raise ValueError("coefficients and prototypes must have shapes BxNxM and BxMxHxW")
        masks = torch.einsum("bnm,bmhw->bnhw", coefficients, prototypes)
        if output_size is None:
            return masks
        batch, count, height, width = masks.shape
        return functional.interpolate(masks.reshape(batch * count, 1, height, width), output_size, mode="bilinear", align_corners=False).reshape(batch, count, *output_size)

    def decode_instance_masks(self, coefficients: Tensor, prototypes: Tensor, boxes: Tensor, output_size: tuple[int, int] = (640, 640)) -> Tensor:
        if boxes.ndim != 3 or boxes.shape[:2] != coefficients.shape[:2] or boxes.shape[-1] != 4:
            raise ValueError("boxes must have shape BxNx4 matching mask coefficients")
        probabilities = torch.sigmoid(self.decode_masks(coefficients, prototypes, output_size))
        height, width = output_size
        y = torch.arange(height, device=boxes.device).view(1, 1, height, 1)
        x = torch.arange(width, device=boxes.device).view(1, 1, 1, width)
        cropped = (x >= boxes[:, :, 0, None, None]) & (x < boxes[:, :, 2, None, None]) & (y >= boxes[:, :, 1, None, None]) & (y < boxes[:, :, 3, None, None])
        return probabilities * cropped.to(probabilities.dtype)

    def compatibility(self) -> dict[str, int]:
        return {"num_classes": self.num_classes, "prototype_dim": self.prototype_dim, "reg_max": self.reg_max}

    def load_compatible_state_dict(self, state: Mapping[str, Any], metadata: Mapping[str, Any]) -> None:
        for key, value in self.compatibility().items():
            if int(metadata.get(key, -1)) != value:
                raise ValueError(f"checkpoint incompatibility for {key}")
        self.load_state_dict(state, strict=True)

    def load_pretrained(self, path: Path) -> dict[str, Any]:
        if not path.exists():
            raise FileNotFoundError(path)
        checkpoint = torch.load(path, map_location="cpu", weights_only=False)
        candidate = checkpoint.get("model", checkpoint) if isinstance(checkpoint, dict) else checkpoint
        source = candidate.state_dict() if isinstance(candidate, nn.Module) else candidate
        if not isinstance(source, Mapping):
            raise ValueError("pretrained checkpoint does not contain a state dictionary")
        destination = self.state_dict()
        layer_map = {"stem": 0, "stage2_down": 1, "stage2": 2, "p3_down": 3, "p4_down": 5, "p5_down": 7, "psa": 10, "down_p3": 18, "down_p4": 21}
        translated: dict[str, Tensor] = {}
        skipped: list[str] = []
        mismatched: list[str] = []
        for target_prefix, source_index in layer_map.items():
            source_prefix = f"model.{source_index}."
            for source_key, value in source.items():
                if source_key.startswith(source_prefix):
                    target_key = f"{target_prefix}.{source_key[len(source_prefix):]}"
                    if target_key in destination:
                        if destination[target_key].shape == value.shape:
                            translated[target_key] = value
                        else:
                            mismatched.append(f"{source_key}->{target_key}")
        for key, value in source.items():
            if key in destination and destination[key].shape == value.shape:
                translated[key] = value
        mapped_source = {key.split("->", 1)[0] for key in mismatched}
        for target_prefix, source_index in layer_map.items():
            mapped_source.update(key for key in source if key.startswith(f"model.{source_index}."))
        skipped.extend(sorted(key for key in source if key not in mapped_source and key not in destination))
        self.load_state_dict(translated, strict=False)
        loaded_parameters = sum(value.numel() for value in translated.values())
        total_parameters = sum(value.numel() for value in destination.values())
        return {"loaded_tensor_count": len(translated), "loaded_parameter_count": loaded_parameters, "loaded_parameter_ratio": float(loaded_parameters / max(1, total_parameters)), "skipped_layers": skipped, "unmatched_layers": skipped, "shape_mismatch_layers": sorted(mismatched)}
