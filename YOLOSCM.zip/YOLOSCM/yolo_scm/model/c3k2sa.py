from __future__ import annotations

import torch
from torch import Tensor, nn

from yolo_scm.model.common import ConvBNAct, ResidualBottleneck, make_divisible
from yolo_scm.model.shuffle_attention import ShuffleAttention


class C3K2SA(nn.Module):
    def __init__(self, c1: int, c2: int, repeats: int = 1, expansion: float = 0.125, groups: int = 8, kernel_size: int = 3) -> None:
        super().__init__()
        if repeats < 1 or kernel_size != 3:
            raise ValueError("C3K2SA requires positive repeats and a 3x3 bottleneck kernel")
        hidden = make_divisible(max(16, int(c2 * expansion)), 2 * groups)
        self.cv1 = ConvBNAct(c1, hidden * 2, 1)
        self.blocks = nn.ModuleList(ResidualBottleneck(hidden, kernel_size=kernel_size) for _ in range(repeats))
        self.attention = ShuffleAttention(hidden, groups)
        self.cv2 = ConvBNAct(hidden * (repeats + 2), c2, 1)

    def forward(self, value: Tensor) -> Tensor:
        first, second = self.cv1(value).chunk(2, dim=1)
        features: list[Tensor] = [first, second]
        current = first
        for block in self.blocks:
            current = self.attention(block(current))
            features.append(current)
        return self.cv2(torch.cat(features, dim=1))
